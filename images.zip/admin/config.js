DRMApp.config(['$routeProvider', function($routeProvider) {
   
	$routeProvider
		.when('/dashboard', {
			controller: 'adminController',
			templateUrl: 'resources/template/dashboard.html'
		})
		
		//system admin forms
		.when('/admin/basicConfiguration', {
			controller: 'adminController',
			templateUrl: 'resources/admin/views/basicConfiguration.html'
			
		})	
		
		.when('/admin/RoleUseMapConfiguration', {
			controller: 'adminController',
			templateUrl: 'resources/admin/views/RoleUseMapConfiguration.html'
			
		})	
		
		.otherwise({ redirectTo : "/admin/basicConfiguration"});
}]);

