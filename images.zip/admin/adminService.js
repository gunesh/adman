DRMApp.service('adminService', function ($http,$q,configParameter,$rootScope) {
	
	 this.getAllDRMRoleUserMap = function() {
			var d = $q.defer();
			$http.get('/'+configParameter.contextPath+'/drmRoleUserMapService/getAllDRMRoleUserMap').success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		 this.getAllDRMRole = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/roleService/getAllDRMRole').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
		this.createUpdateDRMRoleUserMap = function(roleObject) {
			var d = $q.defer();
			 $http.post('/'+configParameter.contextPath+'/drmRoleUserMapService/createUpdateDRMRoleUserMap',roleObject).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		 this.getAllDRMUserDetails = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmUserDetailsService/getAllDRMUserDetails').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.createUpdateDRMRoleUserMapForUser = function(userObject) {
				var d = $q.defer();
				 $http.post('/'+configParameter.contextPath+'/drmRoleUserMapService/createUpdateDRMRoleUserMapForUser',userObject).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getAllDRMResources = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmResourcesService/getAllDRMResources').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getAllDRMRoleUserResourcesMap = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmRoleUserResourcesMapService/getAllDRMRoleUserResourcesMap').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.getAllDRMUserDevices = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmUserDevicesService/getAllDRMUserDevices').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
	 this.getAllDRMTenantDetails = function() {
			var d = $q.defer();
			$http.get('/'+configParameter.contextPath+'/tenantService/getAllDRMTenantDetails').success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		this.createUpdateDRMProjectDetails = function(projectObject) {
			var d = $q.defer();
			 $http.post('/'+configParameter.contextPath+'/projectService/createUpdateDRMProjectDetails',projectObject).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		this.createUpdateDRMTenantDetails = function(tenantObject) {
			var d = $q.defer();
			 $http.post('/'+configParameter.contextPath+'/tenantService/createUpdateDRMTenantDetails',tenantObject).success(
							function(response) {
								
								d.resolve(response);
							}).error(function(error) {
						console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
			this.createUpdateDRMSubProject = function(subProjectObject) {
				var d = $q.defer();
				 $http.post('/'+configParameter.contextPath+'/subProjectService/createUpdateDRMSubProject',subProjectObject).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.getDRMProjectDetailByTenantId = function(tenantId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/projectService/getDRMProjectDetailByTenantId/'+tenantId).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			 this.getAllDRMProjectDetails = function() {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/projectService/getAllDRMProjectDetails').success(
									function(response) {

										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});

					return d.promise;
				};
				
			this.getAllDRMSubProject = function() {
						var d = $q.defer();
						$http.get('/'+configParameter.contextPath+'/subProjectService/getAllDRMSubProject').success(
										function(response) {

											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});

						return d.promise;
					};
				
					this.createUpdateDRMUserDevices = function(userDeviceDTO) {
						var d = $q.defer();
						 $http.post('/'+configParameter.contextPath+'/drmUserDevicesService/createUpdateDRMUserDevices',userDeviceDTO).success(
										function(response) {

											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});

						return d.promise;
					};
					
					this.createUpdateDRMRoleUserResourcesMap = function(resourceMapDTO) {
						var d = $q.defer();
						 $http.post('/'+configParameter.contextPath+'/drmRoleUserResourcesMapService/createUpdateDRMRoleUserResourcesMap',resourceMapDTO).success(
										function(response) {

											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});

						return d.promise;
					};
					
					this.getAllDRMReportLogByUserLogin = function(userLogin,uploadedFor) {
						var d = $q.defer();
						$http.get('/'+configParameter.contextPath+'/drmReportLogService/getAllDRMReportLogByUserName/'+userLogin+'/'+uploadedFor).success(
										function(response) {
											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});
						return d.promise;
					};
});


