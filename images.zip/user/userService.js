DRMApp.service('userService', function ($http,$q,configParameter,$rootScope) {
	
	 this.getAllDRMRoleUserMap = function() {
			var d = $q.defer();
			$http.get('/'+configParameter.contextPath+'/drmRoleUserMapService/getAllDRMRoleUserMap').success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		 this.refreshConfigData = function(tenantId) {
			var d = $q.defer();
			$http.get('/'+configParameter.contextPath+'/configDetailService/refreshConfigDetails/'+tenantId+'/1').success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		 this.getAllDRMRole = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/roleService/getAllDRMRole').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			 this.getDRMRoleUserMapDetailsByTenantIdAndProjectAndSubProjectId = function(tenantId,projectId,subProjectName,forRoleDetail) {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/drmRoleUserMapService/getDRMRoleUserMapDetailsByTenantIdAndProjectAndSubProjectId/'+tenantId+'/'+projectId+'/'+subProjectName+'/'+forRoleDetail).success(
									function(response) {

										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});

					return d.promise;
				};			
			
		this.createUpdateDRMRoleUserMap = function(roleObject) {
			var d = $q.defer();
			 $http.post('/'+configParameter.contextPath+'/drmRoleUserMapService/createUpdateDRMRoleUserMap',roleObject).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		 this.getAllDRMUserDetailsByTenantId = function(tenantId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmUserDetailsService/getAllDRMUserDetailsByTenantId/'+tenantId).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.createUpdateDRMRoleUserMapForUser = function(userObject) {
				var d = $q.defer();
				 $http.post('/'+configParameter.contextPath+'/drmRoleUserMapService/createUpdateDRMRoleUserMapForUser',userObject).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getAllDRMResources = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmResourcesService/getAllDRMResources').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getAllDRMRoleUserResourcesMap = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmRoleUserResourcesMapService/getAllDRMRoleUserResourcesMap').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.getAllDRMUserDevicesByTenanId = function(tenantId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmUserDevicesService/getAllDRMUserDevicesByTenanId/'+tenantId).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getDRMTenantDetailById = function(tenantId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/tenantService/getDRMTenantDetailById/'+tenantId).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

				return d.promise;
		};
		
		this.createUpdateDRMProjectDetails = function(projectObject) {
			var d = $q.defer();
			 $http.post('/'+configParameter.contextPath+'/projectService/createUpdateDRMProjectDetails',projectObject).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		this.createUpdateDRMTenantDetails = function(tenantObject) {
			var d = $q.defer();
			 $http.post('/'+configParameter.contextPath+'/tenantService/createUpdateDRMTenantDetails',tenantObject).success(
							function(response) {
								
								d.resolve(response);
							}).error(function(error) {
						console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
			this.createUpdateDRMSubProject = function(subProjectObject) {
				var d = $q.defer();
				 $http.post('/'+configParameter.contextPath+'/subProjectService/createUpdateDRMSubProject',subProjectObject).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.getDRMProjectDetailByTenantId = function(tenantId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/projectService/getDRMProjectDetailByTenantId/'+tenantId).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			this.getAllDRMSubProjectByTenantIdAndProjectId = function(tenantId,projectId) {
						var d = $q.defer();
						$http.get('/'+configParameter.contextPath+'/subProjectService/getAllDRMSubProjectByTenantIdAndProjectId/'+tenantId+'/'+projectId).success(
										function(response) {

											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});

						return d.promise;
					};
				
			this.getConfigDetailByTypeNSubType = function(configType,
							configSubType) {
						var url = '';
						if (configSubType) {
							url = "/"+configParameter.contextPath+"/configDetailService/getAllConfigDetailByTypeNSubType/"
									+ $rootScope.tenantId
									+ "/"
									+ configParameter.programId
									+ "/"
									+ configType
									+ "/" 
									+ configSubType;
						} else {
							url = "/"+configParameter.contextPath+"/configDetailService/getAllConfigDetailByType/"
									+ $rootScope.tenantId + "/" + configParameter.programId + "/" + configType;
						}
						var d = $q.defer();
						$http.get(url).success(function(response) {
							var elementList = [];
							var dataType;

							angular.forEach(response, function(item) {
								dataType = item.configDataType;
								switch (dataType) {
								case 1:
									// pick from config_str_value
									elementList.push({
										"name" : item.configAlias,
										"value" : item.configStrVal,
										"configType" : item.configType,
										"configSubType" : item.configSubType,
										"configKey" : item.configKey
									});
									break;
								case 2:
									// pick from config_int_value
									elementList.push({
										"name" : item.configAlias,
										"value" : item.configIntVal,
										"configType" : item.configType,
										"configSubType" : item.configSubType,
										"configKey" : item.configKey
									});
									break;
								case 3:
									// pick from configDoubleVal
									elementList.push({
										"name" : item.configAlias,
										"value" : item.configDoubleVal,
										"configType" : item.configType,
										"configSubType" : item.configSubType,
										"configKey" : item.configKey
									});
									break;
								case 4:
									// pick from configDateTimeVal
									elementList.push({
										"name" : item.configAlias,
										"value" : item.configDateTimeVal,
										"configType" : item.configType,
										"configSubType" : item.configSubType,
										"configKey" : item.configKey
									});
									break;
								case 5:
									// pick from configBooleanValue
									elementList.push({
										"name" : item.configAlias,
										"value" : item.configBooleanValue,
										"configType" : item.configType,
										"configSubType" : item.configSubType,
										"configKey" : item.configKey
									});
									break;
								default:
									// do nothing
								}
							});

							d.resolve(elementList);
						}).error(function(error) {

							d.reject(error);
						});

						return d.promise;
					};
					this.createUpdateDRMUserDevices = function(userDeviceDTO) {
						var d = $q.defer();
						 $http.post('/'+configParameter.contextPath+'/drmUserDevicesService/createUpdateDRMUserDevices',userDeviceDTO).success(
										function(response) {

											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});

						return d.promise;
					};
					
					this.createUpdateDRMRoleUserResourcesMap = function(resourceMapDTO) {
						var d = $q.defer();
						 $http.post('/'+configParameter.contextPath+'/drmRoleUserResourcesMapService/createUpdateDRMRoleUserResourcesMap',resourceMapDTO).success(
										function(response) {

											d.resolve(response);
										}).error(function(error) {
									//console.log(JSON.stringify(error));
									d.reject(error);
								});

						return d.promise;
					};
});


