DRMApp.config(['$routeProvider', function($routeProvider) {
   
	$routeProvider
		.when('/dashboard', {
			controller: 'userController',
			templateUrl: 'resources/template/dashboard.html'
		})
		
		//system admin forms
		.when('/user/basicConfiguration', {
			controller: 'userController',
			templateUrl: 'resources/admin/views/basicConfiguration.html'
			
		})	
		
		.when('/user/RoleUseMapConfiguration', {
			controller: 'userController',
			templateUrl: 'resources/admin/views/RoleUseMapConfiguration.html'
			
		})	
		
		.otherwise({ redirectTo : "/admin/basicConfiguration"});
}]);

