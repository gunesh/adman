DRMApp.controller('userController',function($scope, $rootScope, userService, configParameter,$timeout,$css,saveTempObjectService,$q,DRMService,authenticationService,$window) {
	
	
	
	$scope.uploadFileTypes=[" ","xls","xlsx","XLS","XLSX"];
	
	$scope.userConfigInvalid={
			invalidEmail:false
	};
	$scope.search={
			val:null
	};
	$scope.itemsPerPage={
			value:0	
	};
	$scope.tempEmailId={
			val:null	
	};
	$scope.searchForSubProjecttable=function(value, index, array){
		if(angular.isDefined($scope.search.val)&&$scope.search.val!='' &&null!=$scope.search.val && value.project!=null && value.project.tenant!=null){
			var searchValue=$scope.search.val.toLowerCase();
			
			if(null!= value.project.tenant.tenantName && value.project.tenant.tenantName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.project.projectName && value.project.projectName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.subProjectName && value.subProjectName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.subProjectDesc && value.subProjectDesc.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else{
				return false;
			}
		}else{
			return true;
		}
	};
		
	$scope.searchForActiveuserTable=function(value,index,array){
		if(angular.isDefined($scope.search.val) && $scope.search.val!='' && null!=$scope.search.val  && value!=null){
			var searchValue=$scope.search.val.toLowerCase();
			
			if(null!= value.userLogin && value.userLogin.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.drmUserDetails && null!= value.drmUserDetails.userFName && value.drmUserDetails.userFName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.drmProject && null!= value.drmProject.projectName && value.drmProject.projectName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.drmProject && null!= value.drmProject.tenant && null!=value.drmProject.tenant.tenantName && value.drmProject.tenant.tenantName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else{
				return false;
			}
		}else{
			return true;
		}
	};
	$scope.searchForUserTable=function(value, index, array){
		
		if(angular.isDefined($scope.search.val)&&$scope.search.val!='' &&null!=$scope.search.val && value.drmUserDetails!=null && value.project!=null && value.project.tenant!=null){
			var searchValue=$scope.search.val.toLowerCase();
			
			if(value.role!=null && value.role.roleName!=null && value.role.roleName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.userManagerId && value.userManagerId.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.userLogin && value.drmUserDetails.userLogin.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.userFName && value.drmUserDetails.userFName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.drmUserDetails.userMName && value.drmUserDetails.userMName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.userLName && value.drmUserDetails.userLName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.drmUserDetails.companyName && value.drmUserDetails.companyName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.drmUserDetails.userMobilePhone && value.drmUserDetails.userMobilePhone.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.userWorkPhone && value.drmUserDetails.userWorkPhone.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.userPersonalEmail && value.drmUserDetails.userPersonalEmail.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.userWorkEmail && value.drmUserDetails.userWorkEmail.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.tehsil && value.drmUserDetails.tehsil.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.street && value.drmUserDetails.street.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.area && value.drmUserDetails.area.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.city && value.drmUserDetails.city.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.state && value.drmUserDetails.state.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null != value.drmUserDetails.country && value.drmUserDetails.country.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.project.tenant.tenantName && value.project.tenant.tenantName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.project.projectName && value.project.projectName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else if(null!= value.subProject && null!=value.subProject.subProjectName && value.subProject.subProjectName.toLowerCase().indexOf(searchValue)!=-1){
				return true;
			}else{
				return false;
			};
		}else{
			return true;
		};
	};
	
	$scope.sortKey={
			name:'',
			reverse:false
	};
	$scope.sort = function(keyname){
        $scope.sortKey.name = keyname;   //set the sortKey to the param passed
        $scope.sortKey.reverse = !$scope.sortKey.reverse; //if true make it false and vice versa
    };
	
	$scope.mainForm={};
	$scope.changeState=function(value,functionName,accessibilityValues,headerLabel){
		 var res =null;
		 if(angular.isDefined(value)){
			res= value.replace("admin", "user");	 
		 }
		$scope.adminScreen=res;	
		$scope.headerLabel=headerLabel;
	     if(angular.isFunction($scope[functionName])){
	    	  $scope[functionName](accessibilityValues);
	     }
	     
	};	
	 $css.bind({ 
		    href: 	$rootScope.cssFilePath
		  }, $rootScope);
	 
	 		$scope.configParameter=configParameter;
	 		$scope.drmParentDTO={};
			$scope.tenantDTO={}	;
			$scope.projectDTO={};
			$scope.subProjectDTO={};
			$scope.showEditModal={};
			$scope.showEditTenantModal={};
			$scope.showEditUserDeviceModal={};
			$scope.showEditProjectModal={};
			$scope.showEditSubProjectModal={};
			$scope.showEditResourceMapModal={};
			
			$scope.projectNameErrorMsg={
					msg:'',
					value:false,
					equal:2,
					isProjectMatch:null
			};
			$scope.subProjectNameErrorMsg={
					msg:'',
					value:false,
					equal:2,
					isSubProjectMatch:null
			};
			$scope.tenantNameErrorMsg={
					msg:'',
					value:false,
					equal:2,
					isTenantMatch:null
			};
			
			$scope.roleNameErrorMsg={
					msg:'',
					value:false,
					equal:2,
					isTenantMatch:null
			};
			$scope.userNameErrorMsg={
					msg:'',
					value:false,
					equal:2,
					isTenantMatch:null
			};
			
			
			$scope.disableTenant={
					value:true
			};
			$scope.disableRole={
					value:true
			};
			$scope.disableProject={
					value:true
			};
			$scope.disableSubProject={
					value:true
			};
			$scope.disableUserDevice={
					value:true
			};
			$scope.checkIfTenantIsNull=function(tenantId){
				if(tenantId==null){
					
				}
			};
			
			
			$scope.clearErrorMsg=function(){
			
					$scope.projectNameErrorMsg.value=false;
					$scope.projectNameErrorMsg.msg='';
					$scope.projectNameErrorMsg.className='';
					$scope.isProjectMatch=null;
					$scope.projectNameErrorMsg.equal=2;
					
					$scope.subProjectNameErrorMsg.value=false;
					$scope.subProjectNameErrorMsg.msg='';
					$scope.subProjectNameErrorMsg.className='';
					$scope.subProjectNameErrorMsg.equal=2;
					
					$scope.tenantNameErrorMsg.value=false;
					$scope.tenantNameErrorMsg.msg='';
					$scope.tenantNameErrorMsg.className='';
					$scope.tenantNameErrorMsg.equal=2;
					
					$scope.roleNameErrorMsg.value=false;
					$scope.roleNameErrorMsg.msg='';
					$scope.roleNameErrorMsg.className='';
					$scope.roleNameErrorMsg.equal=2;
					
					$scope.userNameErrorMsg.value=false;
					$scope.userNameErrorMsg.msg='';
					$scope.userNameErrorMsg.className='';
					$scope.userNameErrorMsg.equal=2;
					
					
			
			};

			$scope.checkTenantName=function(tenantName){

				if(!(angular.isDefined(tenantName)) || tenantName==null || tenantName==''){
					$scope.tenantNameErrorMsg.equal=2;
					return false;
				}
				if(angular.isDefined($scope.drmParentDTO.tempTenantForEdit)){
					if($scope.drmParentDTO.tempTenantForEdit==tenantName.toLowerCase()){
						return false;
					}	
				}
				
				
				
				$scope.tenantNameErrorMsg.equal=2;
				$scope.tenantNameErrorMsg.value=false;
				$scope.tenantNameErrorMsg.msg='';
				$scope.tenantNameErrorMsg.className='';
				$scope.tenantNameErrorMsg.isTenantMatch=false;
				for(var i=0;i<$scope.allTenantIds.length;i++){
					
					if( $scope.allTenantIds[i].tenantName.toLowerCase()==tenantName.toLowerCase()){
							$scope.tenantNameErrorMsg={
									msg:'Tenant Name Is Already Present',
									value:true,
									equal:1,
									className:'alert alert-danger'	
									};
							$scope.tenantNameErrorMsg.isTenantMatch=true;
							break;
					};
				}
				if($scope.tenantNameErrorMsg.isTenantMatch==false){
					$scope.tenantNameErrorMsg.value=true;
					$scope.tenantNameErrorMsg.equal=0;
					$scope.tenantNameErrorMsg.msg='Tenant Name is available';
					$scope.tenantNameErrorMsg.className='alert alert-success';
				};

			};
			
			$scope.checkRoleName=function(roleName){

				if(!(angular.isDefined(roleName)) || roleName==null || roleName==''){
					$scope.roleNameErrorMsg.equal=2;
					return false;
				}
				if(angular.isDefined($scope.drmParentDTO.tempRoleForEdit)){
					if($scope.drmParentDTO.tempRoleForEdit.toLowerCase()==roleName.toLowerCase()){
						return false;
					}	
				}
				
				
				$scope.roleNameErrorMsg.equal=2;
				$scope.roleNameErrorMsg.value=false;
				$scope.roleNameErrorMsg.msg='';
				$scope.roleNameErrorMsg.className='';
				$scope.roleNameErrorMsg.isRoleMatch=false;
				for(var i=0;i<$scope.roleList.length;i++){
					
					if( $scope.roleList[i].roleName.toLowerCase()==roleName.toLowerCase()){
							$scope.roleNameErrorMsg={
									msg:'Role Name Is Already Present',
									value:true,
									equal:1,
									className:'alert alert-danger'	
									};
							$scope.roleNameErrorMsg.isRoleMatch=true;
							break;
					};
				}
				if($scope.roleNameErrorMsg.isRoleMatch==false){
					$scope.roleNameErrorMsg.value=true;
					$scope.roleNameErrorMsg.equal=0;
					$scope.roleNameErrorMsg.msg='Role Name is available';
					$scope.roleNameErrorMsg.className='alert alert-success';
				};

			};
			
			
			$scope.checkSubProjectName=function(subProjectName,projectId){

				if(!(angular.isDefined(subProjectName) || angular.isDefined(projectId)) || subProjectName==null || subProjectName==''){
					$scope.subProjectNameErrorMsg.equal=2;
					return false;
				}
				if(angular.isDefined($scope.drmParentDTO.tempSubProjectNameForEdit)){
					if($scope.drmParentDTO.tempSubProjectNameForEdit.toLowerCase()==subProjectName.toLowerCase()){
						return false;
					}	
				}
				$scope.subProjectNameErrorMsg.equal=2;
				$scope.subProjectNameErrorMsg.value=false;
				$scope.subProjectNameErrorMsg.msg='';
				$scope.subProjectNameErrorMsg.className='';
				$scope.subProjectNameErrorMsg.isSubProjectMatch=false;
				for(var i=0;i<$scope.subprojectNameList.length;i++){
					
					if(  $scope.subprojectNameList[i].subProjectName.toLowerCase()==subProjectName.toLowerCase()){
						if(projectId==null || projectId==''){
							$scope.subProjectNameErrorMsg={
									msg:'Name Is Already Present',
									value:true,
									equal:1,
									className:'alert alert-danger'	
									};
							$scope.subProjectNameErrorMsg.isSubProjectMatch=true;
							break;
						}else{
							if(  $scope.subprojectNameList[i].project.projectId==projectId){
								
								$scope.subProjectNameErrorMsg={
										msg:'Name Is Already Present For The Project',
											value:true,
											equal:1,
											className:'alert alert-danger'
								};
								$scope.subProjectNameErrorMsg.isSubProjectMatch=true;
								break;
							};
						};
						
						
					};
				}
				if($scope.subProjectNameErrorMsg.isSubProjectMatch==false){
					$scope.subProjectNameErrorMsg.value=true;
					$scope.subProjectNameErrorMsg.equal=0;
					if(projectId==null || !angular.isDefined(projectId)){
						//$scope.subProjectNameErrorMsg.msg='Sub Project Name is available';
					}else{
						//$scope.subProjectNameErrorMsg.msg='Sub Project Name is available for Project';
					}
					
					$scope.subProjectNameErrorMsg.className='alert alert-success';
				};

			};
			
			$scope.checkProjectName=function(projectName,tenantId){
				
				if(!(angular.isDefined(projectName) || angular.isDefined(tenantId)) || projectName==null || projectName==''){
					$scope.projectNameErrorMsg.equal=2;
					return false;
				}
				if(angular.isDefined($scope.drmParentDTO.tempProjectNameForEdit)){
					if($scope.drmParentDTO.tempProjectNameForEdit.toLowerCase()==projectName.toLowerCase()){
						return false;
					}	
				}
				$scope.projectNameErrorMsg.equal=2;
				$scope.projectNameErrorMsg.value=false;
				$scope.projectNameErrorMsg.msg='';
				$scope.projectNameErrorMsg.className='';
				$scope.projectNameErrorMsg.isProjectMatch=false;
				for(var i=0;i<$scope.projectNameList.length;i++){
					
					if($scope.projectNameList[i].projectName.toLowerCase()==projectName.toLowerCase()){
						if(tenantId==null || tenantId==''){
							$scope.projectNameErrorMsg={
									msg:'Project Name Is Already Present',
									value:true,
									equal:1,
									className:'alert alert-danger'	
									};
							$scope.projectNameErrorMsg.isProjectMatch=true;
							break;
						}else{
							if($scope.projectNameList[i].tenant.tenantId==tenantId){
								
								$scope.projectNameErrorMsg={
										msg:'Project Name Is Already Present For The Tenant',
											value:true,
											equal:1,
											className:'alert alert-danger'
								};
								$scope.projectNameErrorMsg.isProjectMatch=true;
								break;
							};
						};
						
						
					};
				}
				if($scope.projectNameErrorMsg.isProjectMatch==false){
					$scope.projectNameErrorMsg.value=true;
					$scope.projectNameErrorMsg.equal=0;
					if(tenantId==null || !angular.isDefined(tenantId)){
						$scope.projectNameErrorMsg.msg='Project Name is available';
					}else{
						$scope.projectNameErrorMsg.msg='Project Name is available for Tenant';
					}
					
					$scope.projectNameErrorMsg.className='alert alert-success';
				};

			};
			
			
			$scope.checkUserName=function(userLogin,subprojectId){

				if(!(angular.isDefined(userLogin)) || userLogin==null || userLogin==''){
					$scope.userNameErrorMsg.equal=2;
					return false;
				}
				if(angular.isDefined($scope.drmParentDTO.tempUserForEdit)){
					if($scope.drmParentDTO.tempUserForEdit.toLowerCase()==userLogin.toLowerCase()){
						return false;
					}	
				}
				
				$scope.userNameErrorMsg.equal=2;
				$scope.userNameErrorMsg.value=false;
				$scope.userNameErrorMsg.msg='';
				$scope.userNameErrorMsg.className='';
				$scope.userNameErrorMsg.isDrmUserDetailsMatch=false;
				
				for(var i=0;i<$scope.allRoles.length;i++){
					if($scope.allRoles[i].drmUserDetails!=null){
							if( $scope.allRoles[i].drmUserDetails.userLogin.toLowerCase()==userLogin.toLowerCase()){
								$scope.userNameErrorMsg={
										msg:'User Login Name Is Already Present',
										value:true,
										equal:1,
										className:'alert alert-danger'	
										};
								$scope.userNameErrorMsg.isDrmUserDetailsMatch=true;
								break;
							};
					}
				}
				if($scope.userNameErrorMsg.isDrmUserDetailsMatch==false){
					$scope.userNameErrorMsg.value=true;
					$scope.userNameErrorMsg.equal=0;
					//$scope.userNameErrorMsg.msg='User Login Name is available';
					$scope.userNameErrorMsg.className='alert alert-success';
				};

			};
			
			
			$scope.setTempTenant=function(tenantIdVal){
				$scope.tempTenantId={
						val:angular.copy(tenantIdVal)
				};
			};
			$scope.setDataInSubProject=function(Object){
				$scope.drmParentDTO.tempSubProjectNameForEdit=angular.copy(Object.subProjectName.toLowerCase());
				$scope.subProjectDTO=angular.copy(Object);
				
				//$scope.getTenantNameByProejctId($scope.subProjectDTO.project.projectId);
			};
			$scope.setDataInTenant=function(tenant){
				$scope.drmParentDTO.tempTenantForEdit=angular.copy(tenant.tenantName.toLowerCase());
				$scope.tenantDTOCopy=angular.copy(tenant);
			};
			$scope.setDataInProject=function(project){
				$scope.drmParentDTO.tempProjectNameForEdit=angular.copy(project.projectName);
				$scope.projectDTOCopy=angular.copy(project);
				$scope.tempTenantId={
						val:angular.copy($scope.projectDTOCopy.tenant.tenantId)
				};
			};
			$scope.clearObjectValuesForBasicCofig=function(){
				$scope.subProjectDTO={}	;
				$scope.projectDTOCopy={};
				$scope.tenantDTOCopy={};
				$scope.tenatObjectFromProject={};
			};
			$scope.getTenantNameByProejctId=function(prjectId){
				if(prjectId==null){
					$scope.tenatObjectFromProject=null;
				}
				angular.forEach($scope.projectNameList,function(projectObject)
						{
							if(projectObject.projectId==prjectId){
								$scope.tenatObjectFromProject=angular.copy(projectObject.tenant);
								$scope.projectDTOToSend=projectObject;
							}
						});
				
			};
			
			$scope.saveTenantData=function(tenantObjectData){
				if ($scope.mainForm.tenantForm.$invalid) {
					return false;
				}
				$('#tenant-module').modal('hide');
				if(tenantObjectData.tenantId ==null){
					tenantObjectData.createdBy=$rootScope.userLogin;	
				}else{
					tenantObjectData.modifiedBy=$rootScope.userLogin;	
				}
					
				userService.createUpdateDRMTenantDetails(tenantObjectData).then(function success(response) {
							$scope.getAllDRMTenantDetails();

							$scope.tenantDTO={}	;
							$scope.notifyAlert({'title' : "Success",'notification':'Tenant Data Saved Successfully'});
						}, function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors
										.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors
										.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
						});
				
			};
			$scope.saveProjectData=function(projectObject){
				if ($scope.mainForm.projectForm.$invalid) {
					return false;
				}
				$('#project-module').modal('hide');
				if(projectObject.projectId ==null){
					projectObject.createdBy=$rootScope.userLogin;	
				}else{
					projectObject.modifiedBy=$rootScope.userLogin;	
				}
				projectObject.tenant={
						tenantId:$rootScope.tenantId
				}
				
				userService.createUpdateDRMProjectDetails(projectObject).then(function success(response) {
						$scope.getDRMProjectDetailByTenantId();
						$scope.notifyAlert({'title' : "Success",'notification':'Project Data Saved Successfully'});

					
						}, function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors
										.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors
										.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
					});
					
				};
				$scope.saveAllData=function(subProjectObject){
					userService
					.createUpdateDRMSubProject(subProjectObject)
					.then(
							function success(response) {
							
						
								
							}, function error(error) {
								$rootScope.errors = [];
								if (error != null) {
									$rootScope.errors
											.push({
												code : error.exception,
												message : error.exceptionMessage
											});
								} else {
									$rootScope.errors
											.push({
												code : "System Error",
												message : "Oops Something went wrong . Please contact system administrator"
											});
								}
							});
				};
			$scope.saveSubProjectData=function(subProjectObject){
				if ($scope.mainForm.subprojectForm.$invalid) {
					return false;
				}
				$('#subProject-module').modal('hide');
				if(subProjectObject.subProjectId ==null){
					subProjectObject.createdBy=$rootScope.userLogin;	
				}else{
					subProjectObject.modifiedBy=$rootScope.userLogin;	
				}
				//subProjectObject.project=$scope.projectDTOToSend;
				var projectId=$rootScope.projectId;
				subProjectObject.project={};
				subProjectObject.project.projectId=projectId;
				userService
					.createUpdateDRMSubProject(subProjectObject)
					.then(
							function success(response) {
						
						$scope.getAllDRMSubProjectByTenantIdAndProjectId();
						$scope.notifyAlert({'title' : "Success",'notification':'Sub Project Data Saved Successfully'});
					
						}, function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors
										.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors
										.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
					});
					
				};
			
			$scope.createTenantObject=function(){
				var object= new Object();
				object.showEdit=true;
				object.showAdd=true;
				$scope.subprojectNameListShow.push(object);	
			};
			$scope.deleteSubprojectNameListObject=function(Object,index){
				
				if(Object.subProjectId==null){
					$scope.subprojectNameListShow.splice(index, 1);
				}
			};
			$scope.setDetails=function(Object){
				
					$scope.getDRMProjectDetailByTenantId(Object.project.tenant.tenantId);
					$scope.getDRMSubProjectDetailByProejctId(Object.project.projectId);
			};
	/*		 $scope.formatLabelForTenant = function(model) {
				    for (var i=0; i< $scope.allTenantIds.length; i++) {
				      if (model === $scope.allTenantIds[i].tenantId) {
				        return $scope.allTenantIds[i].tenantName;
				      }
				    }
				  };
				  $scope.formatLabelForProject = function(model) {
					    for (var i=0; i< $scope.projectNameList.length; i++) {
					      if (model === $scope.projectNameList[i].projectId) {
					        return $scope.projectNameList[i].projectName;
					      }
					    }
					  };
					  $scope.formatLabelForSubProject = function(model) {
						    for (var i=0; i< $scope.subprojectNameList.length; i++) {
						      if (model === $scope.subprojectNameList[i].subProjectId) {
						        return $scope.subprojectNameList[i].subProjectName;
						      }
						    }
						  };*/
	$scope.getAllDRMTenantDetails=function(accessibilityValues)
	{
		var d = $q.defer();
		$scope.allTenantIds=[];
		userService.getDRMTenantDetailById($rootScope.tenantId).then(function success(response) {
			  $scope.allTenantIds.push(response);
			  
			  if(angular.isDefined(accessibilityValues)){
				  $scope.tenantAccessibilityValuesMap={};
		    	  $scope.tenantAccessibilityValuesMap=accessibilityValues;  
			  }
			  d.resolve(response);     
				}, function error(error) {

					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}

				});
		return d.promise;
	};
	$scope.getDRMProjectDetailByTenantId=function()
	{
		var d = $q.defer();  
	
		userService.getDRMProjectDetailByTenantId($rootScope.tenantId).then(function success(response) {
			  $scope.projectNameList=response;
			  d.resolve(response);     
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
		return d.promise;
	};
	
	/*$scope.getDRMProjectDetailByTenantId=function(tenantId)
	{
		
		$scope.projectNameListObjects=[];
		$scope.subprojectNameListObjects=[];
		angular.forEach($scope.projectNameList,function(projectName)
				{
					if(projectName.tenant.tenantId==tenantId){
						var projectNameObject=angular.copy(projectName);
						$scope.projectNameListObjects.push(projectNameObject);
					}
				});
	};*/
	$scope.getAllDRMSubProjectByTenantIdAndProjectId=function(accessibilityValues)
	{
		 var projectId=null;
		 if($rootScope.roleType==configParameter.PROJECT_ADMIN){
			 projectId=$rootScope.projectId;
		 }
		  var d = $q.defer();   
		  userService.getAllDRMSubProjectByTenantIdAndProjectId($rootScope.tenantId,projectId).then(function success(response) {
			  $scope.subprojectNameList=angular.copy(response);
			  $scope.subProjectObjectFromTenant=angular.copy(response);
			  $scope.subprojectNameListShow=angular.copy(response);
			 
			  d.resolve(response);     
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
		return d.promise;
	};
	$scope.getDRMSubProjectDetailByProejctId=function(projectId)
	{
		
		$scope.subprojectNameListObjects=[];
		angular.forEach($scope.subprojectNameList,function(subProjectName)
				{
					if(subProjectName.project.projectId==projectId){
						var subProjectNameObject=angular.copy(subProjectName);
						$scope.subprojectNameListObjects.push(subProjectNameObject);
					}
				});
	};
	
	
	//pratima
	
	/*
	$scope.setDataInSubProject=function(Object){
		$scope.subProjectDTO=angular.copy(Object);
	};*/
	
	$scope.setDataRole=function(all){
		$scope.roleDTOCopy=angular.copy(all);
		$scope.drmParentDTO.tempRoleForEdit=$scope.roleDTOCopy.roleName;
		$scope.getProjectByTenantId($scope.roleDTOCopy.project.tenant.tenantId);
		$scope.getSubProjectByProjectId($scope.roleDTOCopy.project.projectId);
		
	};
	
	$scope.setDataInuser=function(all){
		/*$scope.drmParentDTO.tempTenantForEdit=angular.copy(all.drmUserDetails.userLogin.toLowerCase());
		$scope.userDTO=angular.copy(all);*/
		$scope.userDTO=angular.copy(all);
		$scope.userDTO.drmUserDetails.resetAndPublishPassword=0;
		$scope.userDTO.drmUserDetails.createAndPublishPassword=0;
		$scope.drmParentDTO.tempUserForEdit=$scope.userDTO.drmUserDetails.userLogin;
		//$scope.getProjectByTenantId($scope.userDTO.project.tenant.tenantId);
		//$scope.getSubProjectByProjectId($scope.userDTO.project.projectId);
		$scope.tempProjectId={
				val:angular.copy($scope.userDTO.project.projectId)
		};
		$scope.tempRoleId={
				val:angular.copy($scope.userDTO.role.roleId)
		};
		$scope.tempEmailId={
				val:angular.copy($scope.userDTO.drmUserDetails.userPersonalEmail)
		};
		$scope.getSubProjectByProjectId($scope.userDTO.project.projectId);
		if($scope.userDTO.subProject==null){
			$scope.getRoleByUserRoleTypeandSubprojectId(null);
			//$scope.getRoleByProjectAndTennat($scope.userDTO.project.projectId,$scope.tenantId,null);	
		}else{
			$scope.getRoleByUserRoleTypeandSubprojectId($scope.userDTO.subProject);
			//$scope.getRoleByProjectAndTennat($scope.userDTO.project.projectId,$scope.tenantId,$scope.userDTO.subProject.subProjectId);
		}
		
	};
	$scope.clearObjectValues=function(){
		$scope.tenantDTO={}	;
		$scope.projectDTO={}	;
		$scope.subProjectDTO={}	;
		$scope.userDTO ={};
		$scope.roleDTOCopy={};
		
	};
	
	  $scope.getAllDRMRole=function()
		{
		  var d = $q.defer();   
			userService
			.getAllDRMRole()
			.then(
					function success(response) {
						
				  $scope.allRole=response;
				  d.resolve(response);        
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
			return d.promise;
		};

		 $scope.getDRMRoleUserMapDetailsByTenantIdAndProjectAndSubProjectId=function(forRoleDetail)
			{
			 var projectId=null;
			 var subProjectName=null;
			
			 if($rootScope.roleType==configParameter.PROJECT_ADMIN){
				 projectId=$rootScope.projectId;
			 }else if($rootScope.roleType==configParameter.SUBPROJECT_ADMIN){
				  projectId=$rootScope.projectId;
				  subProjectName=$rootScope.subProjectName;
			 }
			  var d = $q.defer();   
				userService.getDRMRoleUserMapDetailsByTenantIdAndProjectAndSubProjectId($rootScope.tenantId,projectId,subProjectName,forRoleDetail).then(function success(response) {
							
					  $scope.allRoles=response;
					  $scope.roleList=[];
					  $scope.userList=[];
					  if(forRoleDetail==true){
						 for(var i=0;i<$scope.allRoles.length;i++){
							  $scope.roleMatched=false;
							  var roleObject={};
							  if(i==0){
								  $scope.roleUserMap=$scope.allRoles[0];
								  roleObject=$scope.allRoles[0].role;
								  roleObject.project=$scope.allRoles[0].project;
								  roleObject.drmUserDetails=$scope.allRoles[0].drmUserDetails;
								  roleObject.subProject=$scope.allRoles[0].subProject;
								  roleObject.id=$scope.allRoles[0].id;
								  $scope.roleList.push(roleObject);
							  }else{
								  for(var j=0;j<$scope.roleList.length;j++){
									  if($scope.roleList[j].roleName==$scope.allRoles[i].role.roleName){
										  $scope.roleMatched=true;
										  break;
									  }
								  }
								  if($scope.roleMatched==false){
									  roleObject=$scope.allRoles[i].role;
									  roleObject.project=$scope.allRoles[i].project;
									  roleObject.drmUserDetails=$scope.allRoles[i].drmUserDetails;
									  roleObject.id=$scope.allRoles[i].id;
									  roleObject.subProject=$scope.allRoles[i].subProject;
									  $scope.roleList.push(roleObject);
								
								  }
								  
							  }
							    
						  }
					  }
					  
					  d.resolve(response);        
						}, function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors
										.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors
										.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
						});
				return d.promise;
			};
		
		  $scope.getAllDRMRoleUserMap=function()
			{
			  var d = $q.defer();                    	   
    
      	 
				userService.getAllDRMRoleUserMap().then(function success(response) {
					
					  $scope.allRoles=response;
					  $scope.roleList=[];
					  $scope.userList=[];
					
					  for(var i=0;i<$scope.allRoles.length;i++){
						  $scope.roleMatched=false;
						  var roleObject={};
						  if(i==0){
							  $scope.roleUserMap=$scope.allRoles[0];
							  roleObject=$scope.allRoles[0].role;
							  roleObject.project=$scope.allRoles[0].project;
							  roleObject.drmUserDetails=$scope.allRoles[0].drmUserDetails;
							  roleObject.subProject=$scope.allRoles[0].subProject;
							  roleObject.id=$scope.allRoles[0].id;
							  $scope.roleList.push(roleObject);
						  }else{
							  for(var j=0;j<$scope.roleList.length;j++){
								  if($scope.roleList[j].roleName==$scope.allRoles[i].role.roleName){
									  $scope.roleMatched=true;
									  break;
								  }
							  }
							  if($scope.roleMatched==false){
								  roleObject=$scope.allRoles[i].role;
								  roleObject.project=$scope.allRoles[i].project;
								  roleObject.drmUserDetails=$scope.allRoles[i].drmUserDetails;
								  roleObject.id=$scope.allRoles[i].id;
								  roleObject.subProject=$scope.allRoles[i].subProject;
								  $scope.roleList.push(roleObject);
							
							  }
							  
						  }
						    
					  }
					  d.resolve(response);        
					 
					 
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
						});
				 return d.promise;
			};
			
			
			$scope.saveRoleData=function(roleObject){
				
				
				if ($scope.mainForm.roleForm.$invalid) {
					return false;
				}
				$scope.roleUserMap={};
				
				$('#Role-module').modal('hide');
				$scope.roleUserMap.id=roleObject.id;
				$scope.roleUserMap.project=roleObject.project;
				
			//	delete roleObject.subProject['project'];
				$scope.roleUserMap.subProject=roleObject.subProject;
				delete roleObject['subProject'];
				delete roleObject['project'];
				delete roleObject['id'];
				if(roleObject['drmUserDetails'] != null){
					$scope.roleUserMap.drmUserDetails=roleObject['drmUserDetails'];
				}
				delete roleObject['drmUserDetails']
				$scope.roleUserMap.role=roleObject;
					if(!angular.isDefined($scope.roleUserMap.id)){
						$scope.roleUserMap.createdBy=$rootScope.userLogin;
					}else{
						$scope.roleUserMap.modifiedBy=$rootScope.userLogin;
					}
				if(!angular.isDefined(roleObject.roleId)){
					$scope.roleUserMap.role.createdBy=$rootScope.userLogin;
				}else{
					$scope.roleUserMap.role.modifiedBy=$rootScope.userLogin;
				}
		
					userService.createUpdateDRMRoleUserMap($scope.roleUserMap).then(function success(response) {
								
					$scope.getAllDRMRoleRelatedData();
								$scope.roleDTO={}	;
								  $scope.notifyAlert({'title' : "Success",'notification':'Role data is saved'});
							}, function error(error) {
							});
					
				};
				
				
			/*	
				$scope.getProjectNameByTenanttId=function(tenantId){
					if(tenantId==null){
						$scope.projectObjectFromTenant=null;
						$scope.subProjectObjectFromTenant=null;
					}
					angular.forEach($scope.subprojectNameList,function(subProjectObject)
							{
								if(subProjectObject.project.tenant.tenantId==tenantId){
									$scope.projectObjectFromTenant=angular.copy(subProjectObject.project);
									$scope.subProjectObjectFromTenant=angular.copy(subProjectObject);
									$scope.tenantDTOToSend=subProjectObject;
									$scope.tenantDTOToSendforProject=subProjectObject.project;
								}
							});

				};*/
				
$scope.getAllDRMUserDetailsByTenantId=function()
	{
		var d = $q.defer();
		$scope.DRMUserDetails=[];
		userService.getAllDRMUserDetailsByTenantId($rootScope.tenantId).then(function success(response) {
			$scope.DRMUserDetails=response;
				  d.resolve(response);  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
		 return d.promise;
	};
	
	
	$scope.saveUserData=function(userObject){
		//userObject.tenantId=userDTO.project.tenant.tenantId;
		userObject.drmUserDetails.firstLogin=true;
		userObject.drmUserDetails.notifyAccChanges=1;
		//userObject.drmUserDetails.deviceEnabled=1;
		if(userObject.drmUserDetails.userId ==null){
			userObject.drmUserDetails.createdBy=$rootScope.userLogin;	
		}else{
			userObject.drmUserDetails.modifiedBy=$rootScope.userLogin;	
		}
		if(userObject.drmUserDetails.resetAndPublishPassword==0){
			userObject.drmUserDetails.resetAndPublishPassword=null;
		}
		if(userObject.drmUserDetails.createAndPublishPassword==0){
			userObject.drmUserDetails.createAndPublishPassword=null;
		}
		if(userObject.id == null){
			userObject.createdBy=$rootScope.userLogin;
		}else{
			userObject.modifiedBy=$rootScope.userLogin;
		}
		
		if(($rootScope.roleType==configParameter.SUBPROJECT_ADMIN || $rootScope.roleType==configParameter.PROJECT_ADMIN)  && !angular.isDefined(userObject.drmUserDetails.userId)){
			
			userObject.project={
					projectId:$rootScope.projectId		
			};
			userObject.project.tenant={
					tenantId:$rootScope.tenantId	
			};
			angular.forEach($scope.subprojectNameList,function(subprojectObj)
					{
						if(subprojectObj.subProjectName==$rootScope.subProjectName){
							userObject.subProject={
									subProjectId:	subprojectObj.subProjectId
							};
						}
					});
			
		};
		angular.forEach($scope.roleObjectFromTenant,function(roleObj)
				{
					if(roleObj.roleId==userObject.role.roleId){
						userObject.role=roleObj;
						userObject.drmUserDetails.role=roleObj;
					};
				});

		 $scope.checkForUniqueEmalIdFromUserTable(userObject.drmUserDetails.userPersonalEmail).then(function success(notValidEmailId){
			 if(notValidEmailId==false){
					userService.createUpdateDRMRoleUserMapForUser(userObject).then(function success(response) {
						$('#user-module').modal('hide');
						$scope.getAllUserRelatedData();
						
						 $scope.notifyAlert({'title' : "Success",'notification':'User data is saved'});
								
							}, function error(error) {
								$rootScope.errors = [];
								if (error != null) {
									$rootScope.errors
											.push({
												code : error.exception,
												message : error.exceptionMessage
											});
								} else {
									$rootScope.errors
											.push({
												code : "System Error",
												message : "Oops Something went wrong . Please contact system administrator"
											});
								}
							});
			 }else{
				 return false;
			 }
			
		 });  
		
	};
	 $scope.getAllDRMResources=function()
		{
		 var d = $q.defer();
		 
			userService.getAllDRMResources().then(function success(response) {
						$scope.allDRMResources=response;
						
						d.resolve(response);  
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
			return d.promise;
		};
	
	
$scope.getAllDRMRoleUserResourcesMap=function()
{
	var d = $q.defer();
	
	userService.getAllDRMRoleUserResourcesMap().then(function success(response) {
				$scope.allDRMRoleUserResources=response;
				d.resolve(response);  
			
			}, function error(error) {
				
				$rootScope.errors = [];
				if (error != null) {
					$rootScope.errors
							.push({
								code : error.exception,
								message : error.exceptionMessage
							});
				} else {
					$rootScope.errors
							.push({
								code : "System Error",
								message : "Oops Something went wrong . Please contact system administrator"
							});
				}
			});
	 return d.promise;
};

$scope.getRoleNameByUserId=function(userId){
	if(userId==null){
		$scope.roleObjectFromUser=null;
	}
	angular.forEach($scope.DRMUserDetails,function(userObject)
			{
				if(userObject.userId==userId){
					$scope.roleObjectFromUser=angular.copy(userObject.role);
					$scope.userDTOToSend=userObject;
				}
			});
	
};

$scope.getRoleByTenantId=function(tenantId)
{
	
		if(angular.isDefined(tenantId)){
			$scope.roleObjectFromTenant=[];
			
			angular.forEach($scope.allRoles,function(tenantObject)
					{
						if(tenantObject.project.tenant.tenantId==tenantId){
							$scope.roleObjectFromTenant.push(tenantObject.role);
						}
					});	
		}
	};

	$scope.getProjectByTenantId=function(tenantId)
	{
		
			if(angular.isDefined(tenantId)){
				$scope.projectObjectFromTenant=[];
				$scope.subProjectObjectFromTenant=[];
				angular.forEach($scope.projectNameList,function(projectObject)
						{
							if(projectObject.tenant.tenantId==tenantId){
								$scope.projectObjectFromTenant.push(projectObject);
							}
						});	
			}
		};
		
		$scope.getSubProjectByProjectId=function(projectId)
		{
				if(angular.isDefined(projectId)){
					$scope.subProjectObjectFromTenant=[];
					
					angular.forEach($scope.subprojectNameList,function(subProjectObject)
							{
								if(subProjectObject.project.projectId==projectId){
									$scope.subProjectObjectFromTenant.push(subProjectObject);
								}
							});	
				}
			};
$scope.getResourceByResourceId=function(resourceId){
	if(resourceId==null){
		$scope.resourceObjectFromName=null;
	}
	angular.forEach($scope.allDRMResources,function(resourceObject)
			{
				if(resourceObject.resourceId==resourceId){
					$scope.resourceObjectFromName=angular.copy(resourceObject);
					$scope.resourceDTOToSend=resourceObject;
				}
			});
	
};
			
// harshad
$scope.getConfigDetailByTypeNSubType = function(configType,
		configSubType, subscope,tenantId) {
	var d = $q.defer();
	if($scope[subscope] == undefined){
		$scope[subscope]=[];
	}
	if ($scope[subscope].length==0 ) {
		DRMService
				.getConfigDetailByTypeNSubType(configType,
						configSubType,tenantId)
				.then(
						function success(response) {
							$scope[subscope] = [];
							$scope[subscope] = response;
							d.resolve(response);  
						},
						function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors
										.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors
										.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
						});
		}else if ($scope[subscope].length>0 ) {
			d.resolve($scope[subscope]);  
		}
	 return d.promise;
	
	};
	//harshad
	$scope.setDataUserDevice=function(allDRMUserDevices){
		$scope.userDeviceDTOCopy=angular.copy(allDRMUserDevices);
	};
	//harshad
	$scope.clearObjectValuesForUserDevice=function(){
		$scope.userDeviceDTOCopy={};
	};
	//harshad
	$scope.showLabel = function(list,value) {
		var selected = null;
		if(list!=undefined){
			angular.forEach(list, function(s) {
				if (s.value == value) {
				selected = s.name;
				}
			});
			return selected;	
		}
	};
	$scope.saveUserDeviceData=function(userDeviceDTOCopy){
		angular.forEach($scope.DRMUserDetails, function(DRMUser) {
			if (DRMUser.userId == userDeviceDTOCopy.drmUserDetails.userId) {
				userDeviceDTOCopy.drmUserDetails=DRMUser;
			}
		});
		userService.createUpdateDRMUserDevices(userDeviceDTOCopy)
		.then(
				function success(response) {
					
					$scope.getAllDRMUserDevicesByTenanId();
					 $scope.notifyAlert({'title' : "Success",'notification':'User Device Data Saved Successfully'});
				  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
	};

	 $scope.getAllDRMUserDevicesByTenanId=function()
		{
			var d = $q.defer();
			
			userService.getAllDRMUserDevicesByTenanId($rootScope.tenantId).then(function success(response) {
						$scope.allDRMUserDevices=response;
						 d.resolve(response);  
						
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
						
					});
		 return d.promise;
		};
		
		$scope.getAllProjectRelatedData=function(accessibilityValues){
			if(angular.isDefined(accessibilityValues)){
				  $scope.projectAccessibilityValuesMap={};
		    	  $scope.projectAccessibilityValuesMap=accessibilityValues;
			  }
				 $scope.getDRMProjectDetailByTenantId(accessibilityValues);    		        	 			      																	
		};
		$scope.getAllDRMSubProjectRelatedData=function(accessibilityValues){
			/*console.log('role Type :' + $rootScope.roleType);
			console.log('tenant Name :' + $rootScope.tenantName);*/
			 $scope.errorReportLog = null;
			 
			 if(angular.isDefined(accessibilityValues)){
				  $scope.subProjectAccessibilityValuesMap={};
		    	  $scope.subProjectAccessibilityValuesMap=accessibilityValues;
			  }
				 $scope.getDRMProjectDetailByTenantId().then(function success(data){
					 $scope.getAllDRMSubProjectByTenantIdAndProjectId(accessibilityValues).then(function success(data){
						 $scope.getAllDRMReportLogByUserLogin().then(function success(data){
							 
						 });
					 });  
				 });    		        	 			      																	
		};
		
		$scope.getAllDRMResourceRelatedData=function(accessibilityValues){
			if(angular.isDefined(accessibilityValues)){
				  $scope.resourceMapAccessibilityValuesMap={};
		    	  $scope.resourceMapAccessibilityValuesMap=accessibilityValues;  
			  }
			$scope.refreshConfigData(configParameter.DRM_TENANT_ID).then(function success(configrefresh){
				$scope.getConfigDetailByTypeNSubType(configParameter.RESOURCE,configParameter.RESOURCE_TYPE,'resourceTypeConfigDetailList',configParameter.DRM_TENANT_ID).then(function(response){
					
					$scope.getConfigDetailByTypeNSubType(configParameter.DEVICE,configParameter.DEVICE_TYPE,'deviceConfigDetailList',configParameter.DRM_TENANT_ID).then(function(deviceconfigResponse){
						
						$scope.getAllDRMRoleUserResourcesMap().then(function success(data){
							 
							 $scope.getAllDRMUserDetailsByTenantId().then(function success(data)
								{ 				
								 	$scope.getAllDRMResources().then(function success(data){
								 		$scope.getAllDRMRole().then(function success(allRoles){
								 			
								 		});
									});	        	 			      																	
								});	
						 }); 
					}); 
					 
				});
			});
		};
	
		
		$scope.getAllDRMDeviceRelatedData=function(accessibilityValues){
			if(angular.isDefined(accessibilityValues)){
				  $scope.userDeviceAccessibilityValuesMap={};
		    	  $scope.userDeviceAccessibilityValuesMap=accessibilityValues;  
			  }
			 $scope.getAllDRMUserDetailsByTenantId().then(function success(data)
				{ 				
				 	$scope.getAllDRMUserDevicesByTenanId().then(function success(data){
				 		$scope.refreshConfigData(configParameter.DRM_TENANT_ID).then(function success(configrefresh){
				 			$scope.getConfigDetailByTypeNSubType(configParameter.DEVICE,configParameter.DEVICE_TYPE,'deviceConfigDetailList',configParameter.DRM_TENANT_ID);	
				 		});
				 		  
				 	});    		        	 			      																	
				});	
		};
		$scope.getAllDRMResourceRelatedDataModel=function(){
			
			 $scope.getAllDRMUserDetailsByTenantId().then(function success(data)
				{ 				
				 	$scope.getAllDRMResources().then(function success(data){
					 
					});	        	 			      																	
				});	
		};
		$scope.getAllDRMRoleRelatedData=function(accessibilityValues){
			 if(angular.isDefined(accessibilityValues)){
				  $scope.roleAccessibilityValuesMap={};
		    	  $scope.roleAccessibilityValuesMap=accessibilityValues;  
			  }
			/* $scope.getAllDRMRoleUserMap().then(function success(data)
				{
				 $scope.getConfigDetailByTypeNSubType(configParameter.ROLE,configParameter.ROLE_TYPE,'roleTypeConfigDetailList',configParameter.DRM_TENANT_ID).then(function(response){
					 $scope.getAllDRMSubProjectRelatedData();	 
				 });
                });		
			 */
			 $scope.getDRMRoleUserMapDetailsByTenantIdAndProjectAndSubProjectId(true).then(function success(data)
				{
				 $scope.refreshConfigData(configParameter.DRM_TENANT_ID).then(function success(configrefresh){
					 $scope.getConfigDetailByTypeNSubType(configParameter.ROLE,configParameter.ROLE_TYPE,'roleTypeConfigDetailList',configParameter.DRM_TENANT_ID).then(function(response){
						 $scope.getAllDRMSubProjectRelatedData();	 
					 });	 
				 });
				 
             });		
			 
			 
		};
		
		$scope.getAllUserRelatedData=function(accessibilityValues){
			 if(angular.isDefined(accessibilityValues)){
				  $scope.userAccessibilityValuesMap={};
		    	  $scope.userAccessibilityValuesMap=accessibilityValues;  
			  }
			 $scope.errorReportLog = null;
			 $scope.getDRMRoleUserMapDetailsByTenantIdAndProjectAndSubProjectId(false).then(function success(data)
				{
				 console.log(data);
				 $scope.refreshConfigData(configParameter.DRM_TENANT_ID).then(function success(configrefresh){
						$scope.getConfigDetailByTypeNSubType(configParameter.ROLE,configParameter.ROLE_TYPE,'roleTypeConfigDetailList',configParameter.DRM_TENANT_ID).then(function(response){
					 		$scope.getConfigDetailByTypeNSubType(configParameter.DEVICE,configParameter.DEVICE_TYPE,'deviceConfigDetailList',configParameter.DRM_TENANT_ID).then(function(deviceconfigResponse){
					 			$scope.getRoleListByTenantIdAndProjectId().then(function success(roleResponse){
					 				$scope.roleResponseList=roleResponse;
					 					if($rootScope.roleType==configParameter.TENANT_ADMIN ){
							 				$scope.getAllDRMSubProjectRelatedData();	
							 			}else if($rootScope.roleType==configParameter.SUBPROJECT_ADMIN || $rootScope.roleType==configParameter.PROJECT_ADMIN){
							 				$scope.getAllDRMSubProjectByTenantIdAndProjectId().then(function success(response1){
							 					$scope.getRoleByUserRoleTypeandSubprojectId(null);
								 				$scope.getAllDRMReportLogByUserLogin().then(function success(data){
													 
												});
							 				});
//							 				/$scope.getRoleByProjectAndTennat($rootScope.projectId,$rootScope.tenantId,null);
							 			}
					 					
					 			});
					 			
					 		});
					 		
					 		
					 	});
				 });
				 
				});
			 
			 /*$scope.getAllDRMUserDetailsByTenantId().then(function success(data)
				{ 	
				 	$scope.getAllDRMRole().then(function success(data)
				 	{ 				
				 		$scope.getAllDRMRoleRelatedData();    		        	 			      																	
				 	});	
				});	*/
		};
		
		$scope.getRoleListByTenantIdAndProjectId=function(){
			var d = $q.defer();
			DRMService.getRoleListByTenantIdAndProjectId($rootScope.tenantId,$rootScope.projectId).then(function success(response) {
						  d.resolve(response);  
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
						
					});
			 return d.promise;
		};
		$scope.checkForUniqueEmalIdFromUserTable=function(emailId){
			var d = $q.defer();
			if(!angular.isDefined(emailId) || emailId==null || emailId==''){
				var response=true;
				 d.resolve(response); 
				 return d.promise;
			}
			if($scope.tempEmailId.val==emailId){
				var response=false;
				 d.resolve(response); 
				 return d.promise;
			}
			
			DRMService.checkForUniqueEmalIdFromUserTable(emailId).then(function success(response) {
					if(response==true){
						$scope.userConfigInvalid.invalidEmail=true;
						$scope.userDTO.drmUserDetails.userPersonalEmail=null;
					}else{
						$scope.userConfigInvalid.invalidEmail=false;
					}
						  d.resolve(response);  
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
						
					});
			 return d.promise;
		};
		$scope.saveResourceData=function(resourceMapDTOCopy){
			
			$scope.getAllAccessbilityByAccessbilityType(configParameter.accessbilityType).then(function(drmAccessbilityList){
				 var drmAccessbilityMap={};
				 angular.forEach(drmAccessbilityList,function(drmAccessbility)
							{
					 			drmAccessbilityMap[drmAccessbility.accessbilityPosition]=drmAccessbility.accessbilityLabelAlias;
							});
				 	var binaryValue="00000000";
					 for( var prop in drmAccessbilityMap ) {
						 for(var accessibilityValuesMapObj in resourceMapDTOCopy.accessibilityValuesMap){
							 if( drmAccessbilityMap.hasOwnProperty( prop ) ) {
					             if( drmAccessbilityMap[ prop ] === accessibilityValuesMapObj ){
				
					            	 
					            	 binaryValue = binaryValue.substr(0, prop) + resourceMapDTOCopy.accessibilityValuesMap[accessibilityValuesMapObj] + binaryValue.substr(prop + 1);
					         
					            	 break;
					            	
					             }
					        } 
						 }
					    }
					 //to reverse binary value
					 binaryValue= binaryValue.split("").reverse().join("");
					 
						var accessibilityType = parseInt(binaryValue, 2);
						resourceMapDTOCopy.accessibilityType=accessibilityType;
						if(resourceMapDTOCopy.id == null){
							resourceMapDTOCopy.createdBy=$rootScope.userLogin;	
						}else{
							resourceMapDTOCopy.modifiedBy=$rootScope.userLogin;	
						}
						userService.createUpdateDRMRoleUserResourcesMap(resourceMapDTOCopy).then(function success(response) {
							$scope.notifyAlert({'title' : "Success",'notification':'Resouce Map Data Saved Successfully'});
							$scope.getAllDRMResourceRelatedData();
							}, function error(error) {
										$rootScope.errors = [];
										if (error != null) {
											$rootScope.errors
													.push({
														code : error.exception,
														message : error.exceptionMessage
													});
										} else {
											$rootScope.errors
													.push({
														code : "System Error",
														message : "Oops Something went wrong . Please contact system administrator"
													});
										}
										
									});
			});
			
		};
	
		$scope.setResourceMapData=function(resourceMap){
			
			
			$scope.resourceMapDTOCopy=angular.copy(resourceMap);
			$scope.getAllAccessbilityByAccessbilityType(configParameter.accessbilityType).then(function(drmAccessbilityList){
				 var drmAccessbilityMap={};
				 angular.forEach(drmAccessbilityList,function(drmAccessbility)
							{
					 			drmAccessbilityMap[drmAccessbility.accessbilityPosition]=drmAccessbility.accessbilityLabelAlias;
							});
				
				 $scope.drmAccessbilityMapArray=[];
				 for(var key in drmAccessbilityMap){
					 $scope.drmAccessbilityMapArray.push(drmAccessbilityMap[key]);
				 }
				 $scope.accessibilityValues={};
		 			var binary=Number($scope.resourceMapDTOCopy.accessibilityType).toString(2);
		 			binary=configParameter.binaryNumber.substr(binary.length)+binary;
		 			$scope.accessibilityTypeBinary=angular.copy(binary);
		 			
		 			var j=0;
		 			for(var i=$scope.accessibilityTypeBinary.length-1;i>0;i--){
		 				
		 				if(i<=$scope.accessibilityTypeBinary.length){
		 					var currentChar=$scope.accessibilityTypeBinary.charAt(i);
		 					
		 					if(currentChar==1){
		 						$scope.accessibilityValues[drmAccessbilityMap[j]]=1;
		 					}else{
		 						$scope.accessibilityValues[drmAccessbilityMap[j]]=0;
		 					}
		 				}
		 				j++;
		 			}
		 		
		 			$scope.resourceMapDTOCopy.accessibilityValuesMap=$scope.accessibilityValues;
					//$scope.getRoleNameByUserId($scope.resourceMapDTOCopy.drmUserDetails.userId);
					$scope.getResourceByResourceId($scope.resourceMapDTOCopy.drmResources.resourceId);
			});
 			
		};
		
		$scope.getAllAccessbilityByAccessbilityType=function(accessbilityType){
			var d = $q.defer();
			DRMService.getAllAccessbilityByAccessbilityType(accessbilityType).then(function success(response) {
						  d.resolve(response);  
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
						
					});
			 return d.promise;
		};
		$scope.clearObjectValuesForResourceMap=function(){
			$scope.resourceMapDTOCopy={};
			$scope.roleObjectFromUser=null;
			$scope.resourceObjectFromName=null;
			 
			 $scope.getAllAccessbilityByAccessbilityType(configParameter.accessbilityType).then(function(drmAccessbilityList){
				 var drmAccessbilityMap={};
				 angular.forEach(drmAccessbilityList,function(drmAccessbility)
							{
					 			drmAccessbilityMap[drmAccessbility.accessbilityPosition]=drmAccessbility.accessbilityLabelAlias;
							});
		
				 $scope.drmAccessbilityMapArray=[];
				 for(var key in drmAccessbilityMap){
					 $scope.drmAccessbilityMapArray.push(drmAccessbilityMap[key]);
				 }
			 });
		};
		 
		$scope.setActiveMenuCss= function(i) {
			  $scope.mainForm.activeMenu=i;
		};
		$scope.setResourceForSelectedUser=function(selectedUserId,roleId){
			if(selectedUserId==null){
				$scope.resourceObjectFromName=null;
				if(angular.isDefined($scope.resourceMapDTOCopy.drmResources)){
					$scope.resourceMapDTOCopy.drmResources.resourceId=null;
				}
				$scope.setResourceForSelectedRole(roleId);
				return false;
			}
			$scope.allDRMResourcesCopyedObj=angular.copy($scope.allDRMResources);
			var usedResoucesForUserIdList=[];
			for(var i=0;i<$scope.allDRMRoleUserResources.length;i++){
				if($scope.allDRMRoleUserResources[i].drmUserDetails!=null){
					if(selectedUserId==$scope.allDRMRoleUserResources[i].drmUserDetails.userId){
						usedResoucesForUserIdList.push($scope.allDRMRoleUserResources[i].drmResources.resourceId);
					}	
				}
			}
			if(usedResoucesForUserIdList.length>0){
				for(var i=0;i<usedResoucesForUserIdList.length;i++){
					for(var j=0;j<$scope.allDRMResourcesCopyedObj.length;j++){
						if(usedResoucesForUserIdList[i]==$scope.allDRMResourcesCopyedObj[j].resourceId){
							$scope.allDRMResourcesCopyedObj.splice(j,1);
							break;
						}
					}
				}	
			}
			else{
				$scope.setResourceForSelectedRole(roleId);
				return false;
			}
	
			$scope.allDRMResourcesCopyedObjForRole=angular.copy($scope.allDRMResources);
			var usedResoucesForRoleIdList=[];
			for(var i=0;i<$scope.allDRMRoleUserResources.length;i++){
				if(roleId==$scope.allDRMRoleUserResources[i].role.roleId){
					if($scope.allDRMRoleUserResources[i].drmUserDetails==null){
						usedResoucesForRoleIdList.push($scope.allDRMRoleUserResources[i].drmResources.resourceId);
					}
				}
			}
			if(usedResoucesForRoleIdList.length>0){
				for(var i=0;i<usedResoucesForRoleIdList.length;i++){
					for(var j=0;j<$scope.allDRMResourcesCopyedObj.length;j++){
						if(usedResoucesForRoleIdList[i]==$scope.allDRMResourcesCopyedObj[j].resourceId){
							$scope.allDRMResourcesCopyedObj.splice(j,1);
							break;
						}
					}
				}
			}
			
		};
		$scope.setUserByRoleId=function(roleId){
			 /*$scope.example1data = [ {id: 1, label: "David"}, {id: 2, label: "Jhon"}, {id: 3, label: "Danny"}];*/
			if(roleId != null){
			$scope.userForRoleList=[];
				angular.forEach($scope.DRMUserDetails,function(userObject)
						{
							if(userObject.role.roleId==roleId){
						/*	var userForRoleObject={};
								userForRoleObject.id=userObject.userId;
								userForRoleObject.label=userObject.userLogin;*/
								$scope.userForRoleList.push(userObject);
							}
						});	
				
				
			}else{
				if(angular.isDefined($scope.resourceMapDTOCopy.drmUserDetails)){
					$scope.resourceMapDTOCopy.drmUserDetails.userId=null;	
				}
				if(angular.isDefined($scope.resourceMapDTOCopy.drmResources)){
					$scope.resourceMapDTOCopy.drmResources.resourceId=null;	
					$scope.resourceObjectFromName=null;
					for(var key in $scope.resourceMapDTOCopy.accessibilityValuesMap){
						$scope.resourceMapDTOCopy.accessibilityValuesMap[key]=0;
					 }
				}
			}
		};
		$scope.setResourceForSelectedRole=function(roleId){
			if(roleId==null){
				return false;
			}
			$scope.allDRMResourcesCopyedObj=angular.copy($scope.allDRMResources);
			var usedResoucesForRoleIdList=[];
			for(var i=0;i<$scope.allDRMRoleUserResources.length;i++){
				if(roleId==$scope.allDRMRoleUserResources[i].role.roleId){
					if($scope.allDRMRoleUserResources[i].drmUserDetails==null){
						usedResoucesForRoleIdList.push($scope.allDRMRoleUserResources[i].drmResources.resourceId);	
					}
				}
			}
			for(var i=0;i<usedResoucesForRoleIdList.length;i++){
				for(var j=0;j<$scope.allDRMResourcesCopyedObj.length;j++){
					if(usedResoucesForRoleIdList[i]==$scope.allDRMResourcesCopyedObj[j].resourceId){
						$scope.allDRMResourcesCopyedObj.splice(j,1);
						break;
					}
				}
			}
		
		};
		$scope.getRoleByProjectAndTennat=function(projectId,tenantId,subProjectId){
			if(angular.isDefined(tenantId) && angular.isDefined(projectId) ){
				if(projectId==null){
					$scope.roleObjectFromTenant=[];
					return false;
				}
				$scope.roleObjectFromTenant=[];
				 angular.forEach($scope.allRoles,function(roleUserMapObj)
						{
					 		if(roleUserMapObj.drmUserDetails==null){
					 			if($rootScope.roleType==configParameter.TENANT_ADMIN || $rootScope.roleType==configParameter.PROJECT_ADMIN){
					 				if(subProjectId!=null){
						 				if(roleUserMapObj.project.projectId==projectId){
											if(roleUserMapObj.project.tenant.tenantId==tenantId && roleUserMapObj.role.roleType<configParameter.SUBPROJECT_ADMIN){
												$scope.roleObjectFromTenant.push(roleUserMapObj.role);
											}
										}	
									}else{
										if(roleUserMapObj.project.projectId==projectId){
											if(roleUserMapObj.project.tenant.tenantId==tenantId){
												$scope.roleObjectFromTenant.push(roleUserMapObj.role);
											}
										}	
									}
					 			}else if($rootScope.roleType==configParameter.SUBPROJECT_ADMIN){
										if(roleUserMapObj.project.projectId==projectId){
											if(roleUserMapObj.project.tenant.tenantId==tenantId && roleUserMapObj.role.roleType>=configParameter.SUBPROJECT_ADMIN){
												$scope.roleObjectFromTenant.push(roleUserMapObj.role);
											}
										}	
					 			}
					 		}
						});	
				}
		};
		
		$scope.getRoleByUserRoleTypeandSubprojectId=function(subProjectId){
				
				$scope.roleObjectFromTenant=[];
				 angular.forEach($scope.roleResponseList,function(roleObj)
						{
					 			if($rootScope.roleType==configParameter.TENANT_ADMIN || $rootScope.roleType==configParameter.PROJECT_ADMIN){
					 				if(subProjectId!=null){
					 					if(roleObj.roleType>configParameter.TENANT_ADMIN && roleObj.roleType>configParameter.PROJECT_ADMIN){
					 						$scope.roleObjectFromTenant.push(roleObj);
					 					}
									}else{
										if( roleObj.roleType==configParameter.PROJECT_ADMIN){
											$scope.roleObjectFromTenant.push(roleObj);
										}
									}
					 			}else if($rootScope.roleType==configParameter.SUBPROJECT_ADMIN){
											if( roleObj.roleType>=configParameter.SUBPROJECT_ADMIN){
												$scope.roleObjectFromTenant.push(roleObj);
											}
					 			}
						});	
		};
		$scope.getDRMProjectDetailByTenantId=function(){
			var d = $q.defer();
			userService.getDRMProjectDetailByTenantId($rootScope.tenantId).then(function success(response) {
				$scope.projectNameList=response;
						  d.resolve(response);  
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
						
					});
			 return d.promise;
		};
		
	$scope.refreshConfigData=function(tenantId){
		var d = $q.defer();
		userService.refreshConfigData(tenantId).then(function success(response) {
					  d.resolve(response);  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
					
				});
		 return d.promise;
		};
		
		$scope.createSubprojectMapForDownload=function(list){
			
			var d = $q.defer();
			var subProjectList=[];
			var i=0;
			 angular.forEach(list, function (subProjectObj) {
				var subprojectMap={};
				 //subprojectMap['Sr.'] = ++i;
				 subprojectMap['Tenant Name'] = (null !=subProjectObj.project  && null!=subProjectObj.project.tenant) ?subProjectObj.project.tenant.tenantName:"";
				 subprojectMap['Project Name'] = (null !=subProjectObj.project)?subProjectObj.project.projectName:"";		 
				 subprojectMap['Name'] = subProjectObj.subProjectName;
				 subprojectMap['Description'] = subProjectObj.subProjectDesc;
				 subprojectMap['Enabled'] = subProjectObj.enabled?'Yes':'NO';
				 subProjectList.push(subprojectMap);
			 });
		
			 d.resolve(subProjectList);  
				
			 return d.promise;
		};
		
	$scope.createUserMapForDownload=function(list){
	
			var d = $q.defer();
			var userList=[];
			var i=0;
			 angular.forEach(list, function (userObj) {
				 if(null!=userObj.drmUserDetails){
						var userMap={};
						// userMap['Sr.'] = ++i;
						 userMap['Tenant Name'] = (null !=userObj.project  && null!=userObj.project.tenant) ?userObj.project.tenant.tenantName:""  ;
						 userMap['Project Name'] = (null!=userObj.project)?userObj.project.projectName:"";
						 userMap['Sub Project Name'] =(null != userObj.subProject)?userObj.subProject.subProjectName:"";
						 userMap['Role Name'] = (null != userObj.role)?userObj.role.roleName:"";	 
						 userMap['User Login Name'] =  userObj.drmUserDetails.userLogin;	 
						 userMap['User Enabled'] =  userObj.drmUserDetails.enabled?'Yes':'NO';
						 userMap['User First Name'] =  userObj.drmUserDetails.userFName; 
						 userMap['User Middle Name'] =  userObj.drmUserDetails.userMName;
						 userMap['User Last Name'] =  userObj.drmUserDetails.userLName;
						 userMap['Company Name'] =  userObj.drmUserDetails.companyName;
						 userMap['User Mobile Number'] =  userObj.drmUserDetails.userMobilePhone;
						 userMap['User Work Phone'] =  userObj.drmUserDetails.userWorkPhone;
						 userMap['User Work Email'] =  userObj.drmUserDetails.userWorkEmail;
						 userMap['User Personal Email'] =  userObj.drmUserDetails.userLogin;
						 userMap['Tehsil'] =  userObj.drmUserDetails.userPersonalEmail;
						 userMap['Street'] =  userObj.drmUserDetails.street;
						 userMap['Area'] =  userObj.drmUserDetails.area;
						 userMap['City'] =  userObj.drmUserDetails.city;
						 userMap['State'] =  userObj.drmUserDetails.state;
						 userMap['Country'] =  userObj.drmUserDetails.country;
						 userMap['Manager Id'] = userObj.userManagerId;
						 userList.push(userMap);
				 }
			
			 });
		
			 d.resolve(userList);  
				
			 return d.promise;
		};
		
		
		$scope.downloadReport=function(downloadFor,list){
	
			var d = $q.defer();
			if(downloadFor==configParameter.SUB_PROJECT){
				$scope.createSubprojectMapForDownload(list).then(function success(reponse){
					$scope.callGetReportService(configParameter.Sub_Project_Report,reponse);
				});
				
			}else if(downloadFor==configParameter.USER){
				$scope.createUserMapForDownload(list).then(function success(reponse){
					$scope.callGetReportService(configParameter.User_Report,reponse);
				});
			}
			
			 return d.promise;
		};
		
		$scope.callGetReportService=function(fileName,list){
			
			var downloadLink = document.createElement("a");

			document.body.appendChild(downloadLink);
			downloadLink.style = "display: none";
			DRMService.generateReport(fileName,list).then(
										function success(response) {
											var disposition = response
													.headers('Content-Disposition');

											var fileName = disposition
													.substring(21,
															disposition.length);
											console.log(fileName);
											var file = new Blob(
													[ response.data ], {
														type : 'text/csv'
													});
											
											if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
										    {
										      $window.navigator.msSaveBlob(file,fileName); 
										    } else if((navigator.userAgent.indexOf("Chrome") != -1) || (navigator.userAgent.indexOf("Firefox") != -1) )
										    {
												var fileURL = (window.URL).createObjectURL(file);
												downloadLink.href = fileURL;
												downloadLink.download = fileName;
												downloadLink.click();
										    }
											

										},
										function error(error) {
											$rootScope.errors = [];
											if (error != null) {
												$rootScope.errors
														.push({
															code : error.exception,
															message : error.exceptionMessage
														});
											} else {
												$rootScope.errors
														.push({
															code : "System Error",
															message : "Oops Something went wrong . Please contact system administrator"
														});
											}

									});
			
		};
		
		// harshad
		/* upload file */
		$scope.uploadDocumentAndCreateData = function(picFile) {
			if (!picFile) 
			{
				return false;
			}else if(picFile.size==0){
				$rootScope.notifyAlert({title: "Error ", notification: "File is empty OR size is zero Bytes"});
				$scope.mainForm.picFile='';
			}
			
			else{
				
				var val = picFile.name;
	            var val1 = val.substring(val.indexOf(".") + 1);
	            var val2= val1.split(".")[1];
	             if(val2)
	            	 {
	            	 
	            	 if (val2.length > 0)
		            	{
	            		 $rootScope.notifyAlert({title: "Error ", notification: "Invalid filename"});
		            	$scope.mainForm.picFile='';
			            return false;
		            	}
	            	 }else{
				
			var dots = picFile.name.split(".");
			//get the part AFTER the LAST period.
			var fileType = "." + dots[dots.length-1];

			if(!($scope.uploadFileTypes.join(".").indexOf(fileType) != -1)){
				$rootScope.notifyAlert({title: "Error ", notification: "Invalid file Type"});
				$scope.mainForm.picFile='';
				return false;
			}
			if(picFile.name.length>80){
				$rootScope.notifyAlert({title: "Error ", notification: "File Name should be less than 80 character: So kindly rename and upload it again"});
				$scope.mainForm.picFile='';
				return false;
			}
			
			var formData = new FormData();
			formData.append("file", picFile);
			formData.append("fileName",picFile.name );
			formData.append("uploadedBy", $rootScope.userLogin);
			//formData.append("tableName","User_Report");
			formData.append("tableName",$scope.mainForm.tableName);
			if ((picFile.size / 1024 / 1024) < 3) {

				DRMService.uploadDocumentAndCreateData(formData).then(
								function success(response) {
									$scope.mainForm.picFile='';
									$scope.errorReportLog = null;
									
									if($scope.mainForm.tableName=="User_Report"){
										$scope.getAllUserRelatedData();
									}else if($scope.mainForm.tableName=="Sub_Project_Report"){
										$scope.getAllDRMSubProjectRelatedData();
									}else{
										$scope.getAllUserRelatedData();
									}
								}, function error(error) {
									$rootScope.errors = [];
									if (error != null) {
										$rootScope.errors
												.push({
													code : error.exception,
													message : error.exceptionMessage
												});
									} else {
										$rootScope.errors
												.push({
													code : "System Error",
													message : "Oops Something went wrong . Please contact system administrator"
												});
									}
								});

			} else {
				$rootScope.notifyAlert({title: "Error ", notification: "File Size should be less than 3MB"});
				$scope.mainForm.picFile='';
			}
			}
		}
		};
		
		$scope.activeUser={};
		$scope.activeUser.selected = [];
		$scope.addAllUserToken = function(allSelected) {

			if (allSelected) {
				$scope.activeUser.selected = [];
				angular.forEach($scope.allActiveUsers,function(activeUserObj)
				{
					if(activeUserObj.userLogin!=$rootScope.userLogin){
						activeUserObj.selected=true;
						$scope.activeUser.selected.push(activeUserObj.userLogin);	
					}
				});
			} else {
				angular.forEach($scope.allActiveUsers,function(activeUser)
				{
							activeUser.selected=false;
				
				});
				$scope.activeUser.selected = [];
			}
			console.log($scope.activeUser.selected);
		};
		
		$scope.addTokenToList=function(userTokenId,selected){
			if(selected){
				$scope.activeUser.allSelected=false;
				var index = $scope.activeUser.selected.indexOf(userTokenId);
				 if (index == -1) {
					 $scope.activeUser.selected.push(userTokenId);
				 }
			}else{
				$scope.activeUser.allSelected=false;
				 var index = $scope.activeUser.selected.indexOf(userTokenId);
				 if (index > -1) {
					 $scope.activeUser.selected.splice(index, 1);
				 }
			}
		};
		
		
		$scope.getAllActiveDrmUserTokensForTenantIdAndProjectId=function(){
			
			DRMService.getAllActiveDrmUserTokensForTenantIdAndProjectId($rootScope.tenantId,$rootScope.projectId).then(
					function success(response) {
					
						$scope.allActiveUsers=response;
						$scope.refreshConfigData(configParameter.DRM_TENANT_ID).then(function success(configrefresh){
				 			$scope.getConfigDetailByTypeNSubType(configParameter.DEVICE,configParameter.DEVICE_TYPE,'deviceConfigDetailList',configParameter.DRM_TENANT_ID);	
				 		});
						
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
		};
		
		$scope.unBlockUser=function(){
			DRMService.unblockUser($scope.activeUser.selected,$rootScope.projectId).then(
					function success(response) {
						$scope.activeUser.selected=[];
						var allActiveTempList=angular.copy($scope.allActiveUsers);
						$scope.allActiveUsers=[];
						angular.forEach(allActiveTempList, function(value, key) {							  
								var index = response.indexOf(value.userLogin);
							  if (index == -1) {
									 $scope.allActiveUsers.push(value);
							  }
						});
					}, function error(error) {
						$scope.activeUser.selected=[];
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
		};
		
		//Nitin
		$scope.getAllDRMReportLogByUserLogin=function()
		{
			var d = $q.defer();
			DRMService.getAllDRMReportLogByUserLogin($rootScope.userLogin,$scope.mainForm.tableName).then(function success(response) 
			{
			  d.resolve(response);  
			  $scope.reportLog= response;
			}, function error(error) 
			   {
				 $rootScope.errors = [];
				 if (error != null) 
				 {
					$rootScope.errors
					.push({
							code : error.exception,
				    	 message : error.exceptionMessage
						});
				  } else {
						$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
			 return d.promise;
		};	
		
		//Nitin
		$scope.getAllDRMErrorReportLogByDRMReportLogId = function(dmrReportLogId)
		{
			$scope.errorReportLog = null;
			var d = $q.defer();
			DRMService.getAllDRMErrorReportLogByDRMReportLogId(dmrReportLogId).then(function success(response) 
			{
			  d.resolve(response);  
			  $scope.errorReportLog = response;
			}, function error(error) 
			   {
				 $rootScope.errors = [];
				 if (error != null) 
				 {
					$rootScope.errors
					.push({
							code : error.exception,
				    	 message : error.exceptionMessage
						});
				  } else {
						$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
			 return d.promise;
		};	
		
		
		
});

