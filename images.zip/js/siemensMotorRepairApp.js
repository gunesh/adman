var siemensMotorRepairApp = angular.module('siemensMotorRepairApp', ['ui.select','ngRoute','LocalStorageModule','ui.bootstrap','mgcrea.ngStrap','ngAnimate','ngLoadingSpinner','blockUI','ngFileUpload','logger','angularCSS']);

siemensMotorRepairApp.directive('noSpecialChar', function() {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function(scope, element, attrs, modelCtrl) {
        modelCtrl.$parsers.push(function(inputValue) {
          if (inputValue == null)
            return ''
          cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
          if (cleanInputValue != inputValue) {
            modelCtrl.$setViewValue(cleanInputValue);
            modelCtrl.$render();
          }
          return cleanInputValue;
        });
      }
    }
  });

siemensMotorRepairApp.config(['LoggerProvider', function(LoggerProvider) {
		LoggerProvider.log(true);
		LoggerProvider.warn(true);
		LoggerProvider.error(true);
		LoggerProvider.debug(true);
	}])
siemensMotorRepairApp.run(function ($rootScope, $http,authenticationService,$timeout,$interval) {
	
	$rootScope.logoImage='headerImage';
	// $rootScope.logoImage='atosheaderImage';
	//$rootScope.footerText="Siemens AG, 2015 - 2016";
	// $rootScope.footerText="Atos India, 2015 - 2016";

/*	$rootScope.getBuildDetailByTenantIdNsolnCatId = function() {
		var buildDetail=null;
		authenticationService.getBuildDetailByTenantIdNsolnCatId().then(
						function success(response) {
							$rootScope.version  = response.buildVersion;
							$rootScope.time  = response.buildDate;
							if(response.isMarquee==1) {
								$rootScope.marqueeForReleaseNotes = response.releaseNotes;
							}
							
						}, function error(error) {
							console.log("error", error);
						});
		return buildDetail;
	};*/
	
	//$rootScope.buildDetail=$rootScope.getBuildDetailByTenantIdNsolnCatId();
	
    $rootScope.notifier = function (params, callback) {
        $rootScope.error = {}
        $rootScope.error.type = params.type || "message"; //there is also a confirm type which shows Yes and No buttons
        $rootScope.error.title = params.title || "error";
        $rootScope.error.choices = params.choices || [];
        $rootScope.error.notification = params.notification || "Oops! Something went wrong!";
        $("#error-module").modal('show');

        $rootScope.errorResolution = function (status, value) {
            $("#error-module").modal('hide');
            callback(status, value);
        }
    };
    $rootScope.clearInterval = function () {
    	 if (angular.isDefined($rootScope.countPromiseInterval)) {
             $interval.cancel($rootScope.countPromiseInterval);
         }
		 if (angular.isDefined($rootScope.getAlltasksInterval)) {
             $interval.cancel($rootScope.getAlltasksInterval);
         }
    }
	
    $rootScope.notifyAlert = function (params) {
        $rootScope.confirmation = {}
        if(params==undefined){
        	  $rootScope.confirmation.title = "Success";
        	  $rootScope.confirmation.notification= "Data has been submitted successfully";
        }else{
        	  $rootScope.confirmation.title = params.title;
        	  $rootScope.confirmation.notification = params.notification;
        }
        $("#confirmation-module").modal('show');
        $timeout(function () {
            $("#confirmation-module").modal('hide');
        }, 2500);
    }
    
    $rootScope.invalidFormCheck=function(){
    $rootScope.notifier({
		title : "Invalid Data",
		notification : "Please Correct the errors !!!",
		type : "check"
	}, function(resolve) {});
    };
    
    $rootScope.resetCheckedBox=function(inputValue)
	{
		if(!inputValue){
			return null};		
	}
    
	$rootScope.datePicker = (function() {
						var method = {};
						method.instances = [];

						method.open = function($event, instance) {
							$event.preventDefault();
							$event.stopPropagation();

							method.instances[instance] = true;
						};

						method.options = {
							'show-weeks' : false,
							startingDay : 0
						};

						var formats = [ 'MM/dd/yyyy', 'dd-MMMM-yyyy',
								'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate','MMM-yyyy' ];
				           
						method.format = formats[0];

						return method;
					}());
	
	$rootScope.defaultTime=function(selectedDate){
		selectedDate.setHours(9);
		selectedDate.setMinutes(00);
	};

});


siemensMotorRepairApp.filter('unique', function() {

	  // Take in the collection and which field
	  //   should be unique
	  // We assume an array of objects here
	  // NOTE: We are skipping any object which
	  //   contains a duplicated value for that
	  //   particular key.  Make sure this is what
	  //   you want!
	  return function (arr, targetField) {
		  if(arr==undefined){
			  return [];
		  }

	    var values = [],
	        i, 
	        unique,
	        l = arr.length, 
	        results = [],
	        obj;

	    // Iterate over all objects in the array
	    // and collect all unique values
	    for( i = 0; i < arr.length; i++ ) {

	      obj = arr[i];

	      // check for uniqueness
	      unique = true;
	      for( v = 0; v < values.length; v++ ){
	        if( obj[targetField] == values[v] ){
	          unique = false;
	        }
	      }

	      // If this is indeed unique, add its
	      //   value to our values and push
	      //   it onto the returned array
	      if( unique ){
	        values.push( obj[targetField] );
	        results.push( obj );
	      }

	    }
	    return results;
	  };
	})
