DRMApp.run(function ($rootScope, $http, $location,localStorageService,$timeout,$interval,blockUIConfig,$routeParams) {

	
	$rootScope.$on('$routeChangeSuccess', function (event, next, current) {
    	$rootScope.userLogin=null;
		$rootScope.errors = [];
		var currentPath=($location.path());
		if (currentPath != "/dashboard" && currentPath != "/resetPassword") {
			$rootScope.clearInterval();
		}
			if(next.access && next.access=='public')
			{
				$rootScope.passwordRequestId=$routeParams.passwordRequestId;
				$rootScope.url={};
				$rootScope.url.publicUrl=true;
				$location.path(currentPath);
			}
		else
			{
		
		$rootScope.path=currentPath;
		$rootScope.userLogin = localStorageService.get('userLogin');
		$rootScope.userTokenId = localStorageService.get('userTokenId');
		$rootScope.cssFilePath = localStorageService.get('cssFilePath');
		$rootScope.tenantId=localStorageService.get('tenantId');
		$rootScope.sideMenuListItems=localStorageService.get('sideMenuListItems');
		$rootScope.resourcesListForUser=localStorageService.get('resourcesListForUser');
		$rootScope.isSuperAdmin=localStorageService.get('isSuperAdmin');
		$rootScope.isSuperAdmin=parseStringToBoolean($rootScope.isSuperAdmin);
		$rootScope.forcePasswordReset=localStorageService.get('forcePasswordReset');
		$rootScope.tenantName=localStorageService.get('tenantName');
		$rootScope.roleType=localStorageService.get('roleType');
		$rootScope.projectId=localStorageService.get('projectId');
		$rootScope.subProjectName=localStorageService.get('subProjectName');
		$rootScope.projectName=localStorageService.get('projectName');
		
		if( currentPath == "/resetPassword"){
			if($rootScope.forcePasswordReset==0){
				$rootScope.clearInterval();
				window.location.href=tempContextPath+"/login";
			}
		}
		
		if(!$rootScope.userLogin)
		{
			$rootScope.clearInterval();
			window.location.href=tempContextPath+"/login";
		}
		
		}
			
    });
	var parseStringToBoolean=function(value){
		return typeof value == 'string' ? JSON.parse(value) : value;
	};
	if(($location.path())==tempContextPath+"/login"){
		if($rootScope.userLogin)
		{
			window.location.href=tempContextPath+"/user#/dashboard";
		}
	}
	
	$rootScope.$on('event:storeUserLogin', function () {
		localStorageService.set('userLogin', $rootScope.userLogin);
	});
	$rootScope.$on('event:storeCssFilePath', function () {
		localStorageService.set('cssFilePath', $rootScope.cssFilePath);
	});
	$rootScope.$on('event:storeTenantId', function () {
		localStorageService.set('tenantId', $rootScope.tenantId);
	});
	$rootScope.$on('event:storeSideMenuListItems', function () {
		localStorageService.set('sideMenuListItems', $rootScope.sideMenuListItems);
	});
	$rootScope.$on('event:storeResourcesListForUser', function () {
		localStorageService.set('resourcesListForUser', $rootScope.resourcesListForUser);
	});
	$rootScope.$on('event:storeResourcesListForUser', function () {
		localStorageService.set('resourcesListForUser', $rootScope.resourcesListForUser);
	});
	$rootScope.$on('event:storeIsSuperAdmin', function () {
		localStorageService.set('isSuperAdmin', $rootScope.isSuperAdmin);
	});
	$rootScope.$on('event:storeForcePasswordReset', function () {
		localStorageService.set('forcePasswordReset', $rootScope.forcePasswordReset);
	});
	$rootScope.$on('event:storeTenantName', function () {
		localStorageService.set('tenantName', $rootScope.tenantName);
	});
	$rootScope.$on('event:storeRoleType', function () {
		localStorageService.set('roleType', $rootScope.roleType);
	});
	$rootScope.$on('event:storeProjectId', function () {
		localStorageService.set('projectId', $rootScope.projectId);
	});
	$rootScope.$on('event:storeSubProjectName', function () {
		localStorageService.set('subProjectName', $rootScope.subProjectName);
	});
	$rootScope.$on('event:storeProjectName', function () {
		localStorageService.set('projectName', $rootScope.projectName);
	});
	$rootScope.$on('event:storeUserTokenId', function () {
		localStorageService.set('userTokenId', $rootScope.userTokenId);
	});
	
	$rootScope.$on('event:removeDetails', function () {
		localStorageService.remove('userLogin');
		$rootScope.userLogin=null;
		$rootScope.cssFilePath=null;
		$rootScope.tenantId=null;
		$rootScope.sideMenuListItems=null;
		$rootScope.resourcesListForUser=null;
		$rootScope.isSuperAdmin=null;
		$rootScope.forcePasswordReset=null;
		$rootScope.tenantName=null;
		$rootScope.roleType=null;
		$rootScope.projectId=null;
		$rootScope.subProjectName=null;
		$rootScope.projectName=null;
		$rootScope.userTokenId=null;
		
		localStorageService.remove('cssFilePath');
		localStorageService.remove('tenantId');
		localStorageService.remove('sideMenuListItems');
		localStorageService.remove('isSuperAdmin');
		localStorageService.remove('forcePasswordReset');
		localStorageService.remove('tenantName');
		localStorageService.remove('roleType');
		localStorageService.remove('projectId');
		localStorageService.remove('subProjectName');
		localStorageService.remove('projectName');
		localStorageService.remove('userTokenId');
		
	});
});


