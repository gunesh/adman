DRMApp.controller('loginController',function ($scope,$rootScope,authenticationService, $location,configParameter,$timeout,Logger,$css,DRMService,$q,md5,$captcha) {
	
	$scope.invalidOldPassword={
			value:false
	};
	$scope.forgotMainObj={};
	$scope.newPasswordMatchErrorMsg={
		value:false	
	};
	$scope.newPasswordAndOldPswrdMatchErrorMsg={
			value:false		
	};
	$scope.chnagePasswordObj={};
	$scope.forgotPasswordObj={
			tenantName:'',
			projectName:'',
			userName:'',
			resultado:'',
			invalidUserDetail:''
	};
	$scope.forgotIdObj={
			tenantName:'',
			projectName:'',
			userEmailId:'',
			subProjectName:'',
			RoleName:'',
			invalidUserDetail:'',
			resultado:'',
			
	};
	
	$scope.login=function(username,password,loginForm,tenantName,ProjectName,subProjectName)
		{  
		$rootScope.errors = null;
		$scope.loginForm=loginForm;
		if($scope.loginForm.$invalid) return false;
		  var encryptedPass = md5.createHash(password || '');
		  if(!angular.isDefined(subProjectName) || subProjectName==""){
			  subProjectName="";
		  }
	authenticationService.authenticateUser(username,encryptedPass,tenantName,ProjectName,subProjectName).then(function success(response)
		 {
			 if(response!=null && response.status=="Error")
			 {
				 if(response.responseDTO!=null && JSON.parse(response.responseDTO).error=='Please check if Project/Subproject is enabled'){
					 $scope.maxLoginAttemptReached=false;	
					 $scope.invalidProjectDetail=true;	 
					 $scope.invalidDetail=false;
				 }else if(response.responseDTO!=null && JSON.parse(response.responseDTO).error=='Max Login Attempt Reached'){
					 $scope.invalidProjectDetail=false;	 
					 $scope.maxLoginAttemptReached=true;	
					 $scope.invalidDetail=false;
				 }else{
					 $scope.invalidProjectDetail=false;	 
					 $scope.maxLoginAttemptReached=false;	
					 $scope.invalidDetail=false;
					 $scope.invalidDetail=true;
				 }
			 }else{
				 var user={};
					if(response && response.userdetails != null){
						user=JSON.parse(response.userdetails);
						console.log(user);
					};
					 $scope.user=user;
					 $rootScope.forcePasswordReset=$scope.user.forcePasswordReset;
					 $scope.$emit('event:storeForcePasswordReset');
					 $rootScope.userLogin=$scope.user.userLogin;
					 $scope.$emit('event:storeUserLogin');
					 $rootScope.roleType= $scope.user.role.roleType;
					 $scope.$emit('event:storeRoleType');
					 $rootScope.userTokenId= response.userTokenId;
					 $scope.$emit('event:storeUserTokenId');
					 
					
					 authenticationService.getProjectByProjectName(ProjectName).then(function success(projectDetail){
						 
//						 if(response.projectId!=projectObj.projectId || response.tenant.tenantId!=tenantObj.tenantId)
//							 {
//							 $scope.invalidDetailForUserProject=true; 
//							 return false;
//							 }
//						 $rootScope.tenantId=tenantObj.tenantId;
						 $rootScope.tenantId= projectDetail.tenant.tenantId;
						 $scope.$emit('event:storeTenantId');
						 if($rootScope.roleType==configParameter.PROJECT_ADMIN){
							 $rootScope.projectId= projectDetail.projectId;
							 $scope.$emit('event:storeProjectId');
							 $rootScope.projectName= projectDetail.projectName;
							 $scope.$emit('event:storeProjectName');
						 }else if($rootScope.roleType==configParameter.SUBPROJECT_ADMIN){
							 $rootScope.projectName= projectDetail.projectName;
							 $scope.$emit('event:storeProjectName');
							 $rootScope.projectId= projectDetail.projectId;
							 $scope.$emit('event:storeProjectId');
							 $rootScope.subProjectName= subProjectName;
							 $scope.$emit('event:storeSubProjectName');
						 }
						 $rootScope.tenantId= projectDetail.tenant.tenantId;
						 $scope.$emit('event:storeTenantId');
						 $rootScope.tenantName= projectDetail.tenant.tenantName;
						 $scope.$emit('event:storeTenantName');
						 if(projectDetail.tenant.cssFilePath==null){
							 $rootScope.cssFilePath = 'resources/css/DRM.css';
							 $scope.$emit('event:storeCssFilePath');
						 }else{
							 $rootScope.cssFilePath = projectDetail.tenant.cssFilePath;
							 $scope.$emit('event:storeCssFilePath');
						 }
						 if($rootScope.forcePasswordReset==1){
							 window.location.href=tempContextPath+"/forgotPassword#/resetPassword"; 
							 return false;
						 }
						 
					if($scope.user.role.roleType==configParameter.SUPER_ADMIN){
						$rootScope.isSuperAdmin=true;
						$scope.$emit('event:storeIsSuperAdmin');
						$rootScope.sideMenuListItems=[];
						
						 $scope.getAllDRMResourcesIcons().then(function success(drmResourceIconList)
							{ 	
								angular.forEach(drmResourceIconList,function(resourceIconObj)
									{
									 var sidemenuListObject={};
									 	 
										sidemenuListObject.formPath=resourceIconObj.formPath;
										sidemenuListObject.viewPath=resourceIconObj.viewPath;
										sidemenuListObject.label=resourceIconObj.drmResources.resourceAlias;
										sidemenuListObject.name=resourceIconObj.drmResources.resourceName;
										sidemenuListObject.resourceSeq=resourceIconObj.drmResources.resourceSeq;
										sidemenuListObject.triggerFunctionName=resourceIconObj.triggerName;
										$rootScope.sideMenuListItems.push(sidemenuListObject);
									});
							
								$rootScope.sideMenuListItems.sort($scope.custom_sort);
								
								$scope.$emit('event:storeSideMenuListItems');
								window.location.href=tempContextPath+"/admin#/dashboard";   		        	 			      																	
									
							});
					}else{
						$rootScope.isSuperAdmin=false;
						$scope.$emit('event:storeIsSuperAdmin');
						
						$scope.getDRMRoleUserResourcesMapByUserIdAndRoleId( $scope.user.userId, $scope.user.role.roleId).then(function success(data)
						{ 		
						 $scope.drmResourcesList=[];
						 $scope.getAllAccessbilityByAccessbilityType(configParameter.accessbilityType,configParameter.DRM_TENANT_ID).then(function success(drmAccessbilityList)
							{ 
							 
							 var drmAccessbilityMap={};
							 angular.forEach(drmAccessbilityList,function(drmAccessbility)
										{
								
								 			drmAccessbilityMap[drmAccessbility.accessbilityPosition]=drmAccessbility.accessbilityLabelAlias;
								 			
										});
				
							
							 angular.forEach($scope.drmResourcesMapList,function(resourceMapObj)
										{
								 		$scope.accessibilityValues={};
								 			var binary=Number(resourceMapObj.accessibilityType).toString(2);
								 			binary=configParameter.binaryNumber.substr(binary.length)+binary;
								 			$scope.accessibilityTypeBinary=angular.copy(binary);
								 			
								 			var j=0;
								 			for(var i=$scope.accessibilityTypeBinary.length-1;i>0;i--){
								 				
								 				if(i<=$scope.accessibilityTypeBinary.length){
								 					var currentChar=$scope.accessibilityTypeBinary.charAt(i);
								 					
								 					if(currentChar==1){
								 						$scope.accessibilityValues[drmAccessbilityMap[j].toLowerCase()]=true;
								 					}else{
								 						$scope.accessibilityValues[drmAccessbilityMap[j].toLowerCase()]=false;
								 					}
								 				}
								 				j++;
								 			}
								 			if(resourceMapObj.drmResources!=null){
								 				$scope.drmResourcesList.push(resourceMapObj.drmResources);
								 			}
								 
								 			resourceMapObj.drmResources.accessibilityValues=$scope.accessibilityValues;
										});
							 var spliceIndex=[];
							 for(var i=0;i<$scope.drmResourcesMapList.length;i++){
								 for(var j=i+1;j<$scope.drmResourcesMapList.length;j++){
									 if($scope.drmResourcesMapList[i].drmResources.resourceId==$scope.drmResourcesMapList[j].drmResources.resourceId){
										 var userBasedAccessibilityValues={};
										 if($scope.drmResourcesMapList[i].drmUserDetails==null){
											 spliceIndex.push(i);
											 userBasedAccessibilityValues=$scope.drmResourcesMapList[j].drmResources.accessibilityValues;
											 for(var key in userBasedAccessibilityValues){
												 if($scope.drmResourcesMapList[i].drmResources.accessibilityValues[key]==true){
													 $scope.drmResourcesMapList[j].drmResources.accessibilityValues[key]=true;
												 }
											 }
										 }else if($scope.drmResourcesMapList[j].drmUserDetails==null){
											 spliceIndex.push(j);
											 userBasedAccessibilityValues=$scope.drmResourcesMapList[i].drmResources.accessibilityValues;
											 for(var key in userBasedAccessibilityValues){
												 if($scope.drmResourcesMapList[j].drmResources.accessibilityValues[key]==true){
													 $scope.drmResourcesMapList[i].drmResources.accessibilityValues[key]=true;
												 }
											 }
										 }
										 
									 }
								 }
							 }
						
							 for(var i=0;i<spliceIndex.length;i++){
								 $scope.drmResourcesMapList.splice(spliceIndex[i]);	 
							 }
					
							 var resourceDTOListForResourceIcon=[];
							
							 for(var i=0;i<$scope.drmResourcesMapList.length;i++){
								 
								 resourceDTOListForResourceIcon.push($scope.drmResourcesMapList[i].drmResources);
							 }
							 
							 $scope.getDRMResourcesIconsByResourceDTO(resourceDTOListForResourceIcon).then(function success(resourceIconList)
								{ 				
							
								 	$rootScope.sideMenuListItems=[];
									angular.forEach(resourceIconList,function(resourceIconObj)
											{
												if(resourceIconObj.drmResources.resourceType==4){
													var sidemenuListObject={};
													
													sidemenuListObject.formPath=resourceIconObj.formPath;
													sidemenuListObject.viewPath=resourceIconObj.viewPath;
													sidemenuListObject.label=resourceIconObj.drmResources.resourceAlias;
													sidemenuListObject.name=resourceIconObj.drmResources.resourceName;
													sidemenuListObject.resourceSeq=resourceIconObj.drmResources.resourceSeq;
													sidemenuListObject.triggerFunctionName=resourceIconObj.triggerName;
													angular.forEach($scope.drmResourcesMapList,function(resourceMapObj)
															{
																if(resourceMapObj.drmResources.resourceName==sidemenuListObject.name){
																	sidemenuListObject.accessibilityValues=resourceMapObj.drmResources.accessibilityValues;
																	
																}
															});
														
													$rootScope.sideMenuListItems.push(sidemenuListObject);
													
												}
											});
							
									$rootScope.sideMenuListItems.sort($scope.custom_sort);
							
									 $scope.$emit('event:storeSideMenuListItems');
									// window.location.href=tempContextPath+"/admin#/dashboard";
									 window.location.href=tempContextPath+"/user#/dashboard";
											});	
							});
						
						}); 
						}
		              });	
					 
			 }
		 }, 
	     function error(error) {$scope.invalidDetail=true;});
	};
	
	$scope.resetForgotModal=function(){
		 $scope.forgotPasswordObj.tenantName='';
		 $scope.forgotPasswordObj.projectName='';
		 $scope.forgotPasswordObj.subProjectName='';
		 $scope.forgotPasswordObj.resultado='';
		 $scope.forgotPasswordObj.invalidUserDetail=false;
		 $scope.forgotIdObj.tenantName='';
		 $scope.forgotIdObj.projectName='';
		 $scope.forgotIdObj.subProjectName='';
		 $scope.forgotIdObj.invalidUserDetail=false;
		 $scope.forgotIdObj.userEmailId='';
		 $scope.forgotIdObj.RoleName='';
		 $scope.forgotIdObj.resultado='';
		 
	};
	$scope.forgotPassword=function(userName,forgotForm,tenantName,projectName,subProjectName)
	{
		$scope.forIdOrPasswordFlag=2;
		 $scope.forgotPasswordObj.invalidUserDetail=false;
		if (forgotForm.$invalid) { return false; }
		
		  //correct
        if($captcha.checkResult($scope.forgotPasswordObj.resultado) == true)
        {
        	if(!angular.isDefined(subProjectName) || subProjectName==""){
        		subProjectName=null;
        	}
        	
        	authenticationService.getDRMProjectByProjectNameAndTenantNameAndSubProjectNameAndUserLoginName(tenantName,projectName,subProjectName,userName).then(function success(userResponse){	
        	
//        /authenticationService.getDRMUserByProjectDetailByProjectNameAndTenantName(projectName,tenantName,subProjectName).then(function success(userResponse){
        		
        /*authenticationService.getProjectByUserName(userName).then(function success(userResponse){*/
			 
			 if(userResponse==""){
				 $scope.forgotPasswordObj.invalidUserDetail=true;
				 return false;
			 }
				authenticationService.forgotPassword(userName,userResponse.tenant.tenantId,userResponse.projectId).then(
								function success(response)
								 {	 
									
									if(response.error=='false'){
										
										$("#forgotPasswordModal").modal('hide');
										$scope.resetForgotModal();
										$scope.confirmation={};
							        	  $scope.confirmation.title = "Forgot Password !";
							        	  $scope.confirmation.notification = "Forgot Password Link has been sent to your Registerd Email Id";
		  						          $("#confirmationWithOk-module").modal('show');
		  						          
										/*$rootScope.notifyAlert({title:"Forgot Password !",notification:"Forgot Password Link has been sent to your Registerd Email Id"});*/	
									}else if(response.error=='true'){
										if(response.msg.toLowerCase()=='link is allready present and not expired yet'){
											$scope.forgotPassUserName=userName;
											$scope.forgotPassTenantId=userResponse.tenant.tenantId;
											$scope.resetForgotModal();
											$("#forgotPasswordModal").modal('hide');
    										$scope.confirmation={};
								        	  $scope.confirmation.title = "Forgot Password !";
								        	  $scope.confirmation.notification = "Email containing forgotPassword link was already being sent please check Your Email";
			  						          $("#resendEmailConfirmationModal-module").modal('show');
			  						        
										}
									}else{
										$scope.resetForgotModal();
										 $scope.forgotPasswordObj.invalidUserDetail=true;
										 
									}
									
								 },
								 function error(error) {
									 
										$("#forgotPasswordModal").modal('hide');
									 $rootScope.errors = [];
					                if (error != null) {
					                	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
					                  } else {
					                    $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
					                  } 
								 });
												
		
				  
					}, function error(error) {
						$rootScope.errors = [];
		                if (error != null) {
		                	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
		                  } else {
		                    $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
		                  } 
					});
        
	  }
    //error captcha
    else
    {
    	$scope.forgotPasswordObj.resultado=null;
        alert("Error");
    }
	
	
	};
	
	$scope.forgotId=function(userEmailId,forgotIdForm,tenantName,projectName,roleName)
	{
		$scope.forIdOrPasswordFlag=1;
		$scope.forgotIdObj.invalidUserDetail=false;
		$scope.forgotIdObj.invalidUserEmail=false;
		if (forgotIdForm.$invalid) { return false; }
		
		  //correct
        if($captcha.checkResult($scope.forgotIdObj.resultado) == true)
        {
				authenticationService.forgotId(userEmailId,roleName,tenantName,projectName).then(
								function success(response)
								 {	 
									if(response.error=='false'){
										$("#forgotIdModal").modal('hide');
										$scope.resetForgotModal();
										$scope.confirmation={};
										$scope.confirmation.title = "Forgot Password !";
										$scope.confirmation.notification = "Forgot Password Link has been sent to your Registerd Email Id";
										$("#confirmationWithOk-module").modal('show');
		  						          
										/*$rootScope.notifyAlert({title:"Forgot Password !",notification:"Forgot Password Link has been sent to your Registerd Email Id"});*/	
									}else if(response.error=='true'){
										if(response.msg.toLowerCase()=='link is allready present and not expired yet'){
											$scope.forgotPassUserName= response.userName;
											$scope.forgotPassTenantId=response.tenantId;
											$scope.resetForgotModal();
											$("#forgotIdModal").modal('hide');
    										$scope.confirmation={};
    										$scope.confirmation.title = "Forgot Password !";
    										$scope.confirmation.notification = "Email containing forgotPassword link was already being sent please check Your Email";
    										$("#resendEmailConfirmationModal-module").modal('show');
			  						        
										}else if(response.msg.toLowerCase()=='invalid user details'){
											$scope.forgotIdObj.invalidUserDetail=true;
											return false;
										}else if(response.msg.toLowerCase()=='more than one user present for same email id under same role'){
											$scope.forgotIdObj.invalidUserEmail=true;
										}
										
									}else{
										$scope.resetForgotModal();
										$scope.forgotIdObj.invalidUserDetail=true;
									}
									
								 },
								 function error(error) {
									 
										$("#forgotIdModal").modal('hide');
									 $rootScope.errors = [];
					                if (error != null) {
					                	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
					                  } else {
					                    $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
					                  } 
								 });
        
	  }
    //error captcha
    else
    {
    	$scope.forgotIdObj.resultado=null;
        alert("Error");
    }
	
	
	};
	
	$scope.logoutRequest=function(){
		$scope.loadNotifier($scope.logout);
	};
	
	$scope.loadNotifier = function(callback) {

		$scope.notifier({
			title : "Confirm Logout",
			notification : "Are you sure you want to Logout ?",
			type : "confirm"
		}, function(resolve) {
			if (resolve) {

				callback();
			}
		});
	};
	
	$scope.logout=function()
	{
		authenticationService.logoutRequest($rootScope.userLogin,$rootScope.userTokenId).then(
		function success(response)
		 {
			if(response.msg.toLowerCase()=='logout')
			{
				$rootScope.clearInterval();
				$scope.$emit('event:removeDetails');
				window.location.href=tempContextPath+"/login";
			}
		 }, 
	     function error(error) {$rootScope.errors = [];
         if (error != null) {
         	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
           } else {
             $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
           } 
		 });	
		
		//$location.path("/login");
	};
	
	$scope.changePassword=function()
	{
		$scope.chnagePasswordObj={};
		$scope.invalidOldPassword={
			value:false
		};
		
		$("#changePassword").modal('show');
	};
	 $("#changePassword").on("hidden.bs.modal",function(){
		 $scope.chnagePasswordObj={};
			$scope.invalidOldPassword={
					value:false
			};
			$scope.newPasswordMatchErrorMsg.value=false;
			$scope.newPasswordAndOldPswrdMatchErrorMsg.value=false;
	});
	$scope.loggerTest=function(){
		var logger = Logger.getInstance("loginController");
		logger.log('This is a log');
		logger.warn('warn', 'This is a warn');
		logger.error('This is a {0} error! {1}', [ 'big', 'just kidding' ]);
		logger.debug('debug', 'This is a debug for line {0}', [ 8 ]);
	};
	
	$scope.resetPasswordSubmit=function(pass)
	{
		
		var from='web';
		if(pass){
		authenticationService.resetPassword($rootScope.userLogin,pass.newPassword,pass.oldPassword,from).then(
				function success(response)
				 {	
					if(response.error=='false'){
						$scope.invalidOldPassword={
								value:false
						};
						$("#changePassword").modal('hide');
						$scope.confirmation={};
			        	  $scope.confirmation.title = "Reset Password";
			        	  $scope.confirmation.notification = "Password has been changed successfully";
						$("#confirmationWithOk-module").modal('show');
						
					}else{
						$scope.invalidOldPassword={
								value:true
						};
					}
				
				 },
				 function error(error) {
					 $("#changePassword").modal('hide');
					 $rootScope.errors = [];
	                if (error != null) {
	                	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
	                  } else {
	                    $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
	                  } 
				 });};
		
	};
	
	$scope.checkForNewPasswordMatch=function(newPassword,newPasswordCopy){
		$scope.newPasswordMatchErrorMsg={
				msg:'',
				value:false
		};
		if(!newPassword && !newPasswordCopy){
			$scope.newPasswordMatchErrorMsg={
					msg:'',
					value:false
			};
		return false;
		}
		if(newPassword!=newPasswordCopy){
			$scope.newPasswordMatchErrorMsg={
					msg:'new password does not match',
					value:true
			};
		}
		
	};
	
	$scope.checkForOldPasswordMatch=function(newPassword,oldPassword)
	{
	$scope.newPasswordAndOldPswrdMatchErrorMsg={
		msg:'',
		value:false
	};
		if(!newPassword && !oldPassword){
				$scope.newPasswordAndOldPswrdMatchErrorMsg={
			msg:'',
			value:false
				};
					return false;
			}
		if(newPassword==oldPassword){
			$scope.newPasswordAndOldPswrdMatchErrorMsg={
			msg:'new password does not match',
			value:true
			};
		}
	

};

	$scope.getAllProjectRelatedData=function(){
		 $scope.getAllDRMTenantDetails().then(function success(data)
			{ 				
			 $scope.getAllDRMProjectDetails();    		        	 			      																	
        });	
		
	};
	$scope.getAllDRMTenantDetails=function()
	{
		var d = $q.defer();  
		DRMService.getAllDRMTenantDetails().then(function success(response) {
			  $scope.allTenantIds=response;
			  d.resolve(response);     
				}, function error(error) {

					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}

				});
		return d.promise;
	};
	$scope.getAllDRMProjectDetails=function()
	{
		var d = $q.defer();  
	
		DRMService.getAllDRMProjectDetails().then(function success(response) {
			  $scope.projectNameList=response;
			  d.resolve(response);     
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
		return d.promise;
	};
	$scope.getProjectIdByTenantId=function(tenantObj){
		if(angular.isDefined(tenantObj)){
			$scope.projectDataList=[];
			
			angular.forEach($scope.projectNameList,function(projectObj)
					{
						if(projectObj.tenant.tenantId==tenantObj.tenantId){
							$scope.projectDataList.push(projectObj);
						}
					});	
		}else{
			$scope.forgotPasswordObj.projectObj=null;
		}
	};
	/*$scope.getTenantIdByProjectId = function(projectId) {
		if (projectId == null) {
			$scope.tenantDataList = null;
		}
		angular.forEach($scope.projectNameList, function(
				projectObject) {
			if (projectObject.projectId == projectId) {
				$scope.tenantDataList = angular
						.copy(projectObject.tenant);
				$scope.projectDTOToSend = projectObject;
			}
		});

	};
*/
	
	$scope.getAllDRMResources=function(){
		var d = $q.defer();
		DRMService.getAllDRMResources().then(function success(response) {
					$scope.drmResourcesList=response;
					  d.resolve(response);  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
					
				});
		 return d.promise;
	};
	
	$scope.getDRMRoleUserResourcesMapByUserIdAndRoleId=function(userId,roleId){
		var d = $q.defer();
		DRMService.getDRMRoleUserResourcesMapByUserIdAndRoleId(userId,roleId).then(function success(response) {
					$scope.drmResourcesMapList=response;
					  d.resolve(response);  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
					
				});
		 return d.promise;
	};
	
	$scope.getDRMResourcesIconsByResourceDTO=function(drmResourcesList){
		var d = $q.defer();
		DRMService.getDRMResourcesIconsByResourceDTO(drmResourcesList).then(function success(response) {
					
					  d.resolve(response);  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
					
				});
		 return d.promise;
	};
	$scope.custom_sort = function(a, b) {

		return a.resourceSeq>b.resourceSeq;
				
	};
	
	$scope.getAllAccessbilityByAccessbilityType=function(accessbilityType,tenantId){
		var d = $q.defer();
		DRMService.getAllAccessbilityByAccessbilityTypeAndTenanId(accessbilityType,tenantId).then(function success(response) {
					  d.resolve(response);  
				}, function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
					
				});
		 return d.promise;
	};
	
	$scope.getAllDRMResourcesIcons=function(){
		var d = $q.defer();
		DRMService.getAllDRMResourcesIcons().then(function success(response) {
			  d.resolve(response);  
		}, function error(error) {
			$rootScope.errors = [];
			if (error != null) {
				$rootScope.errors
						.push({
							code : error.exception,
							message : error.exceptionMessage
						});
			} else {
				$rootScope.errors
						.push({
							code : "System Error",
							message : "Oops Something went wrong . Please contact system administrator"
						});
			}
			
		});
		return d.promise;
	};
	
	$scope.redirectToLoginPage=function(){
		$rootScope.clearInterval();
		window.location.href=tempContextPath+"/login";
	};
	$scope.resendActivePasswordLinkEmail=function(){
		
		DRMService.resendActivePasswordLinkEmail($scope.forgotPassUserName,$scope.forgotPassTenantId,$scope.forIdOrPasswordFlag).then(
				function success(response)
				 {	
					    $("#resendEmailConfirmationModal-module").modal('hide');
						$scope.confirmation={};
			        	  $scope.confirmation.title = "Forgot Password !";
			        	  $scope.confirmation.notification = "Forgot Password Link has been sent to your Registerd Email Id";
				          $("#confirmationWithOk-module").modal('show');
				
				 },
				 function error(error) {
					 $rootScope.errors = [];
	                if (error != null) {
	                	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
	                  } else {
	                    $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
	                  } 
				 });
		
	};
});