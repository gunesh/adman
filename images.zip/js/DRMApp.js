var DRMApp = angular.module('DRMApp', ['ui.select','ngRoute','LocalStorageModule','ui.bootstrap','mgcrea.ngStrap','ngAnimate','ngLoadingSpinner','blockUI','ngFileUpload','logger','angularCSS','angular-md5','udpCaptcha','ngTable','angularUtils.directives.dirPagination','fixed.table.header','ngCookies']);

DRMApp.directive('noSpecialChar', function() {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function(scope, element, attrs, modelCtrl) {
        modelCtrl.$parsers.push(function(inputValue) {
          if (inputValue == null)
            return ''
          cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
          if (cleanInputValue != inputValue) {
            modelCtrl.$setViewValue(cleanInputValue);
            modelCtrl.$render();
          }
          return cleanInputValue;
        });
      }
    }
  });

DRMApp.config(['LoggerProvider', function(LoggerProvider) {
		LoggerProvider.log(true);
		LoggerProvider.warn(true);
		LoggerProvider.error(true);
		LoggerProvider.debug(true);
	}])
DRMApp.run(function ($rootScope, $http,$timeout,$interval) {
	
	$rootScope.logoImage='headerImage';
	// $rootScope.logoImage='atosheaderImage';
	//$rootScope.footerText="Siemens AG, 2015 - 2016";
	// $rootScope.footerText="Atos India, 2015 - 2016";

/*	$rootScope.getBuildDetailByTenantIdNsolnCatId = function() {
		var buildDetail=null;
		authenticationService.getBuildDetailByTenantIdNsolnCatId().then(
						function success(response) {
							$rootScope.version  = response.buildVersion;
							$rootScope.time  = response.buildDate;
							if(response.isMarquee==1) {
								$rootScope.marqueeForReleaseNotes = response.releaseNotes;
							}
							
						}, function error(error) {
							console.log("error", error);
						});
		return buildDetail;
	};*/
	
	//$rootScope.buildDetail=$rootScope.getBuildDetailByTenantIdNsolnCatId();
	
    $rootScope.notifier = function (params, callback) {
        $rootScope.error = {}
        $rootScope.error.type = params.type || "message"; //there is also a confirm type which shows Yes and No buttons
        $rootScope.error.title = params.title || "error";
        $rootScope.error.choices = params.choices || [];
        $rootScope.error.notification = params.notification || "Oops! Something went wrong!";
        $("#logoutConfirnm-module").modal('show');

        $rootScope.errorResolution = function (status, value) {
            $("#logoutConfirnm-module").modal('hide');
            callback(status, value);
        };
    };
    $rootScope.clearInterval = function () {
    	 if (angular.isDefined($rootScope.countPromiseInterval)) {
             $interval.cancel($rootScope.countPromiseInterval);
         }
		 if (angular.isDefined($rootScope.getAlltasksInterval)) {
             $interval.cancel($rootScope.getAlltasksInterval);
         }
    }
	
    $rootScope.notifyAlert = function (params) {
        $rootScope.confirmation = {}
        if(params==undefined){
        	  $rootScope.confirmation.title = "Success";
        	  $rootScope.confirmation.notification= "Data has been submitted successfully";
        }else{
        	  $rootScope.confirmation.title = params.title;
        	  $rootScope.confirmation.notification = params.notification;
        }
        $("#confirmation-module").modal('show');
        $timeout(function () {
            $("#confirmation-module").modal('hide');
        }, 2500);
    }
    
    $rootScope.invalidFormCheck=function(){
    $rootScope.notifier({
		title : "Invalid Data",
		notification : "Please Correct the errors !!!",
		type : "check"
	}, function(resolve) {});
    };
    
    $rootScope.resetCheckedBox=function(inputValue)
	{
		if(!inputValue){
			return null};		
	}
    
	$rootScope.datePicker = (function() {
						var method = {};
						method.instances = [];

						method.open = function($event, instance) {
							$event.preventDefault();
							$event.stopPropagation();

							method.instances[instance] = true;
						};

						method.options = {
							'show-weeks' : false,
							startingDay : 0
						};

						var formats = [ 'MM/dd/yyyy', 'dd-MMMM-yyyy',
								'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate','MMM-yyyy' ];
				           
						method.format = formats[0];

						return method;
					}());
	
	$rootScope.defaultTime=function(selectedDate){
		selectedDate.setHours(9);
		selectedDate.setMinutes(00);
	};

});


DRMApp.filter('unique', function() {

	  // Take in the collection and which field
	  //   should be unique
	  // We assume an array of objects here
	  // NOTE: We are skipping any object which
	  //   contains a duplicated value for that
	  //   particular key.  Make sure this is what
	  //   you want!
	  return function (arr, targetField) {
		  if(arr==undefined){
			  return [];
		  }

	    var values = [],
	        i, 
	        unique,
	        l = arr.length, 
	        results = [],
	        obj;

	    // Iterate over all objects in the array
	    // and collect all unique values
	    for( i = 0; i < arr.length; i++ ) {

	      obj = arr[i];

	      // check for uniqueness
	      unique = true;
	      for( v = 0; v < values.length; v++ ){
	        if( obj[targetField] == values[v] ){
	          unique = false;
	        }
	      }

	      // If this is indeed unique, add its
	      //   value to our values and push
	      //   it onto the returned array
	      if( unique ){
	        values.push( obj[targetField] );
	        results.push( obj );
	      }

	    }
	    return results;
	  };
	});

DRMApp.factory('httpRequestInterceptor', function ($q,$rootScope,localStorageService) {
	  return {
	    request: function (config) {

	      config.headers['USER_TOKEN_ID'] = $rootScope.userTokenId;
	      config.headers['from'] = 'web';

	      return config;
	    },
	  response: function(response) {
          if (response.status == 200) { 
             // console.log("Response 200"); 
             /* if(response.data=='error:session expirerd'){
              	window.location.href=tempContextPath+"/login"; 	 
              } */
          } 
          return response || $q.when(response); 
  
      },
	    responseError: function(response) { 
            if (response.status == 401 ) { 
            	var isValid=response.headers('Valid');
            	if(isValid=='false'){
            		$rootScope.confirmation={};
                	$rootScope.confirmation.title = "Session is Terminated..!";
                	$rootScope.confirmation.notification = "Your Session Is Expired Redirecting To Login Page";
                	   $("#confirmation-module").modal('show');
                			$rootScope.userLogin=null;
                    		$rootScope.cssFilePath=null;
                    		$rootScope.tenantId=null;
                    		$rootScope.sideMenuListItems=null;
                    		$rootScope.resourcesListForUser=null;
                    		$rootScope.isSuperAdmin=null;
                    		$rootScope.forcePasswordReset=null;
                    		$rootScope.tenantName=null;
                    		$rootScope.roleType=null;
                    		$rootScope.projectId=null;
                    		$rootScope.subProjectName=null;
                    		$rootScope.projectName=null;
                    		$rootScope.userTokenId=null;
                    		
                    		localStorageService.remove('userLogin');
                    		localStorageService.remove('cssFilePath');
                    		localStorageService.remove('tenantId');
                    		localStorageService.remove('sideMenuListItems');
                    		localStorageService.remove('isSuperAdmin');
                    		localStorageService.remove('forcePasswordReset');
                    		localStorageService.remove('tenantName');
                    		localStorageService.remove('roleType');
                    		localStorageService.remove('projectId');
                    		localStorageService.remove('subProjectName');
                    		localStorageService.remove('projectName');
                    		localStorageService.remove('userTokenId');
                    		
                    		setTimeout(function(){ window.location.href=tempContextPath+"/login"; }, 2000);
            	}
            	
                        
                             
            } 
            return $q.reject(rejection); 
        } 
	  
	  };
	});

DRMApp.config(function ($httpProvider) {
	  $httpProvider.interceptors.push('httpRequestInterceptor');
	});