DRMApp
		.service(
				'saveTempObjectService',
				function() {

				    	var tempObj=[];

				        return {
				            getProperty: function () {
				                return tempObj;
				            },
				            setProperty: function(value) {
				            	tempObj = value;
				            }
				        };
				});
