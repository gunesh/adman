DRMApp.service('DRMService',function($http, $q,configParameter,$rootScope) {

	  this.checkForUniqueEmalIdFromUserTable = function(emailId) {
		  
	       var d = $q.defer();
	   
	       $http({
	    	   method: 'GET',
	    	   url: '/'+configParameter.contextPath+'/drmUserDetailsService/checkForUniqueEmalIdFromUserTable',
	    	   headers: {
	    		   'userEmailId': emailId
	          }
	    	   
	    	 })		  
	       .success(function (response) {
	               d.resolve(response);
	           })
	           .error(function (error) {
	           	
		             d.reject(error);
	           });

	       return d.promise;
	   };
				
	
	 this.getRoleListByTenantIdAndProjectId = function(tenantId,projectId) {
		var d = $q.defer();
		$http.get('/'+configParameter.contextPath+'/drmRoleUserMapService/getRoleListByTenantIdAndProjectId/'+tenantId+'/'+projectId).success(
						function(response) {

							d.resolve(response);
						}).error(function(error) {
					//console.log(JSON.stringify(error));
					d.reject(error);
				});

		return d.promise;
	};
	
	 this.getAllDRMTenantDetails = function() {
			var d = $q.defer();
			$http.get('/'+configParameter.contextPath+'/tenantService/getAllDRMTenantDetails').success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
				    
		 this.getAllDRMProjectDetails = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/projectService/getAllDRMProjectDetails').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
				 
			this.getAllDRMResources = function() {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmResourcesService/getAllDRMResources').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getDRMRoleUserResourcesMapByUserIdAndRoleId = function(userId,roleId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmRoleUserResourcesMapService/getDRMRoleUserResourcesMapByUserIdAndRoleId/'+userId+'/'+roleId).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getDRMResourcesIconsByResourceDTO = function(drmResourcesList) {
				var d = $q.defer();
				$http.post('/'+configParameter.contextPath+'/drmResourcesIconsService/getDRMResourcesIconsByResourceDTO',drmResourcesList).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getAllAccessbilityByAccessbilityTypeAndTenanId = function(accessbilityType,tenantId) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmAccessbilityService/getAllAccessbilityByAccessbilityTypeAndTenanId/'+accessbilityType+'/'+tenantId).success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			this.getAllDRMResourcesIcons = function(accessbilityType) {
				var d = $q.defer();
				$http.get('/'+configParameter.contextPath+'/drmResourcesIconsService/getAllDRMResourcesIcons').success(
								function(response) {

									d.resolve(response);
								}).error(function(error) {
							//console.log(JSON.stringify(error));
							d.reject(error);
						});

				return d.promise;
			};
			
			 this.resendActivePasswordLinkEmail = function(userLogin,tenantId,forIdOrPasswordFlag) {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/drmForgotPasswordRequestService/resendActivePasswordLinkEmail/'+userLogin+'/'+tenantId+'/'+forIdOrPasswordFlag).success(
									function(response) {

										d.resolve(response);
									}).error(function(error) {
										d.reject(error);
							});

					return d.promise;
				};
				
				this.getConfigDetailByTypeNSubType = function(configType,
						configSubType,tenantId) {
					var url = '';
					if (configSubType) {
						url = "/"+configParameter.contextPath+"/configDetailService/getAllConfigDetailByTypeNSubType/"
								+ tenantId
								+ "/"
								+ configParameter.programId
								+ "/"
								+ configType
								+ "/" 
								+ configSubType;
					} else {
						url = "/"+configParameter.contextPath+"/configDetailService/getAllConfigDetailByType/"
								+ tenantId + "/" + configParameter.programId + "/" + configType;
					}
					var d = $q.defer();
					$http.get(url).success(function(response) {
						var elementList = [];
						var dataType;

						angular.forEach(response, function(item) {
							dataType = item.configDataType;
							switch (dataType) {
							case 1:
								// pick from config_str_value
								elementList.push({
									"name" : item.configAlias,
									"value" : item.configStrVal,
									"configType" : item.configType,
									"configSubType" : item.configSubType,
									"configKey" : item.configKey
								});
								break;
							case 2:
								// pick from config_int_value
								elementList.push({
									"name" : item.configAlias,
									"value" : item.configIntVal,
									"configType" : item.configType,
									"configSubType" : item.configSubType,
									"configKey" : item.configKey
								});
								break;
							case 3:
								// pick from configDoubleVal
								elementList.push({
									"name" : item.configAlias,
									"value" : item.configDoubleVal,
									"configType" : item.configType,
									"configSubType" : item.configSubType,
									"configKey" : item.configKey
								});
								break;
							case 4:
								// pick from configDateTimeVal
								elementList.push({
									"name" : item.configAlias,
									"value" : item.configDateTimeVal,
									"configType" : item.configType,
									"configSubType" : item.configSubType,
									"configKey" : item.configKey
								});
								break;
							case 5:
								// pick from configBooleanValue
								elementList.push({
									"name" : item.configAlias,
									"value" : item.configBooleanValue,
									"configType" : item.configType,
									"configSubType" : item.configSubType,
									"configKey" : item.configKey
								});
								break;
							default:
								// do nothing
							}
						});

						d.resolve(elementList);
					}).error(function(error) {

						d.reject(error);
					});

					return d.promise;
				};
				this.generateReport = function (fileName,list) {
					
					var d = $q.defer();
			   		return $http.post('/'+configParameter.contextPath+'/genrateReportService/generateReport/'+fileName,list, {responseType : 'arraybuffer',params : {},
			   						}).then(
			   						function(response, status, headers,
			   								config) {

			   							return response;
			   						});
					
			        
				};
				
			  	//harshad: for attachment upload file
			   	this.uploadDocumentAndCreateData = function(formData) {

			   		var d = $q.defer();
			   		$http.post(
			   				'/'+configParameter.contextPath+'/genrateReportService/uploadDocumentAndCreateData',
			   				formData,
			   				{
			   					transformRequest : function(data,
			   							headersGetterFunction) {
			   						return data;
			   					},
			   					headers : {
			   						'Content-Type' : undefined
			   					}
			   				}).success(function(response) {
			   			d.resolve(response);
			   		}).error(function(error) {
			   			d.reject(error);
			   		});
			   		return d.promise;
			   	};
			   	
			   	
			   	this.getAllActiveDrmUserTokensForTenantIdAndProjectId = function(tenantId,projectId) {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/drmUserTokenService/getAllActiveDrmUserTokensForTenantIdAndProjectId/'+tenantId+'/'+projectId).success(
									function(response) {

										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});

					return d.promise;
				};
				
				this.unblockUser = function(userList,projectId) {
					var d = $q.defer();					
					userList.push(projectId);
					$http.post('/'+configParameter.contextPath+'/unblockUser',userList).success(
									function(response) {
										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});

					return d.promise;
				};
			   	this.getAllActiveDRMUserToken = function() {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/drmUserTokenService/getAllActiveDRMUserToken').success(
									function(response) {

										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});

					return d.promise;
				};
				
				this.getAllDRMReportLogByUserLogin = function(userLogin,uploadedFor) {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/drmReportLogService/getAllDRMReportLogByUserName/'+userLogin+'/'+uploadedFor).success(
									function(response) {
										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});
					return d.promise;
				};
				
				this.getAllDRMErrorReportLogByDRMReportLogId = function(dmrReportLogId) {
					var d = $q.defer();
					$http.get('/'+configParameter.contextPath+'/drmReportErrorLogService/getAllDRMErrorReportLogByDRMReportLogId/'+dmrReportLogId).success(
									function(response) {
										d.resolve(response);
									}).error(function(error) {
								//console.log(JSON.stringify(error));
								d.reject(error);
							});
					return d.promise;
				};
});
