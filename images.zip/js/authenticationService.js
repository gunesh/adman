DRMApp.service('authenticationService', function ($http,$q,configParameter) {
	
    this.authenticateUser = function(j_username,j_password,tenant,project,subproject) {
    	var config = {headers:  {
            'Authorization': 'Basic d2VudHdvcnRobWFuOkNoYW5nZV9tZQ==',
            'Accept': 'application/json;odata=verbose',
            "X-Testing" : "testing"
        }
    };
        var d = $q.defer();
        
        $http({
      	   method: 'POST',
      	   url: '/'+configParameter.contextPath+'/j_spring_security_check?j_username='+j_username+'&j_password='+j_password+'&tenant='+tenant+'&project='+project+'&subproject='+subproject+'&_spring_security_remember_me=on',
      	   headers: {
      		   'from':'web'
            }
      	 })    
         .success(function (response, status, headers, config) {
        	 response.userdetails=headers('userdetails');
        	 response.responseDTO=headers('responseDTO');
        	 response.userTokenId=headers('userTokenId');
        	 d.resolve(response);
             })
             .error(function (error) {
            	 console.log(error);
  	             d.reject(error);
             });
        
       // http://localhost:8080/drm-mgmt-ws/j_spring_security_check?j_username=system4&j_password=1110DF3043&_spring_security_remember_me=on
//        $http.post('/drm-mgmt-ws/j_spring_security_check?j_username='+j_username+'&j_password='+j_password+'&_spring_security_remember_me=on')
  /*      $http.post('/'+configParameter.contextPath+'/j_spring_security_check?j_username='+j_username+'&j_password='+j_password+'&tenant='+tenant+'&project='+project+'&_spring_security_remember_me=on') 
        
        //http://localhost:8080/drm-mgmt-ws/login/1/Airtel/fff
        .success(function (response, status, headers, config) {
        	response.userdetails=headers('userdetails');
        	d.resolve(response);
            })
            .error(function (error, status, headers, config) {
            	
	             d.reject(error);
            });*/

        return d.promise;
    };
	 
	 this.getProjectByProjectName = function(projectName) {
  
        var d = $q.defer();
    
        $http.get('/'+configParameter.contextPath+'/projectService/getDRMProjectDetailByProjectName/'+projectName)
        
        .success(function (response) {
            	
                d.resolve(response);
            })
            .error(function (error) {
            	
	             d.reject(error);
            });

        return d.promise;
    };
    
    
	 this.getDRMProjectByProjectNameAndTenantNameAndSubProjectNameAndUserLoginName = function(tenantName,projectName,subProjectName,userName) {
 
       var d = $q.defer();
   
       $http.get('/'+configParameter.contextPath+'/drmRoleUserMapService/getDRMProjectByProjectNameAndTenantNameAndSubProjectNameAndUserLoginName/'+tenantName+'/'+projectName+'/'+subProjectName+'/'+userName)
       
       .success(function (response) {
           	
               d.resolve(response);
           })
           .error(function (error) {
           	
	             d.reject(error);
           });

       return d.promise;
   };
    this.finUserDetailByUserName=function(userName){
        var d = $q.defer();
        
        $http.get('/'+configParameter.contextPath+'/drmUserDetailsService/getDRMUserDetailsByUserName/'+userName)
        
        .success(function (response) {
            	
                d.resolve(response);
            })
            .error(function (error) {
            	
	             d.reject(error);
            });

        return d.promise;
    };
    
    this.logoutRequest = function(userName,userTokenId) {
    	  
        var d = $q.defer();
    
        $http({
     	   method: 'POST',
     	   url: '/'+configParameter.contextPath+'/logOut',
     	   headers: {
     		   'userLogin': userName,
     		   'from':'web',
     		  'userTokenId':userTokenId
           }
     	   
     	 })
    
        .success(function (response) {
            	
                d.resolve(response);
            })
            .error(function (error) {
            	
 	             d.reject(error);
            });

        
        return d.promise;
    };

   
   this.forgotPassword = function(userName,tenantId,projectId) {
	   
       var d = $q.defer();
   
       $http({
    	   method: 'POST',
    	   url: '/'+configParameter.contextPath+'/forgotPasswordRequest/'+tenantId+'/'+projectId,
    	   headers: {
    		   'userLogin': userName,
    		   'timestamp':new Date(),
    		   'from':'web'
          }
    	   
    	 })
       
      /* $http.post('/'+configParameter.contextPath+'/forgotPassword/LAVA',{
    	   headers: {'userLogin': 'system1','imei':'101','timestamp':'2016-02-12','modelName':'df'}
       })
       */
       .success(function (response) {
           	
               d.resolve(response);
           })
           .error(function (error) {
           	
	             d.reject(error);
           });

       return d.promise;
   };
   
   
   this.forgotId = function(userEmailId,roleName,tenantName,projectName) {
	  
       var d = $q.defer();
   
       $http({
    	   method: 'POST',
    	   url: '/'+configParameter.contextPath+'/forgotIdRequest/'+tenantName+'/'+projectName,
    	   headers: {
    		   'userEmailId': userEmailId,
    		   'timestamp':new Date(),
    		   'from':'web',
    		   'roleName':roleName
          }
    	   
    	 })
       
      /* $http.post('/'+configParameter.contextPath+'/forgotPassword/LAVA',{
    	   headers: {'userLogin': 'system1','imei':'101','timestamp':'2016-02-12','modelName':'df'}
       })
       */
       .success(function (response, status, headers, config) {
    	   response.userName=headers('userLogin');
    	   response.tenantId=headers('tenant');
    	   
               d.resolve(response);
           })
           .error(function (error) {
           	
	             d.reject(error);
           });

       return d.promise;
   };
   
      this.getBuildDetailByTenantIdNsolnCatId = function() {
		var d = $q.defer();
		$http.get("/"+configParameter.contextPath+"/buildDetailService/getBuildDetail/SIEMENS/1")
				.success(function(response) {
					d.resolve(response);
				}).error(function(error) {
					
					d.reject(error);
				});
		return d.promise;
	};
   
	   this.resetPassword = function(userName,newPassword,oldPassword,from) {
		   
	       var d = $q.defer();
	   
	       $http({
	    	   method: 'POST',
	    	   url: '/'+configParameter.contextPath+'/changePassword/'+newPassword+'/'+oldPassword,
	    	   headers: {
	    		   'userLogin': userName,	    		
	    		   'timestamp':new Date(),
	       			'from':from
	          }
	      
	       })
	       
	       .success(function (response) {
	           	
	               d.resolve(response);
	           })
	           .error(function (error) {
	           	
		             d.reject(error);
	           });

	       return d.promise;
	   };

   
});

