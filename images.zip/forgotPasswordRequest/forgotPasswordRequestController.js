
DRMApp.controller('forgotPasswordRequestController',function($scope,$routeParams,md5,forgotPasswordRequestService,$rootScope,$css) {
	
	$scope.initialiseCssFile=function(){
		
		$css.bind({ 
		    href: 	$rootScope.cssFilePath
		  }, $rootScope);	
	};
	$scope.disableSubmitButton=false;
	$scope.errorOnNewPassword=false;
	$scope.errorOnRetypePassword=false;
	 $scope.chnagePasswordObj={};
	 $scope.invalidOldPassword={
				value:false
		};
		$scope.newPasswordMatchErrorMsg={
			value:false	
		};
		$scope.newPasswordAndOldPswrdMatchErrorMsg={
				value:false		
		}
//	/  var encryptedPasswordRequestId  = md5.createHash($rootScope.passwordRequestId || '');
	  
		$scope.checkPasswordRequestValidity=function(){
				
			forgotPasswordRequestService.checkPasswordRequestValidity($rootScope.passwordRequestId).then(function success(response) {
				$scope.serviceCalled=true;
				$scope.returnMapObj=response;
				if(response.success=="true"){
					
					if(response.cssFilePath!=null){
						$css.bind({ 
						    href: 	response.cssFilePath
						  }, $rootScope);
					}else{
						$css.bind({ 
						    href: 	'resources/css/DRM.css'
						  }, $rootScope);
					}
					$scope.passwordChangeSuccess=true;
				}else{
					$scope.passwordChangeSuccess=false;
					$css.bind({ 
					    href: 	'resources/css/DRM.css'
					  }, $rootScope);
				}
					}, function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
			
		};
		
		$scope.redirectToLoginPage=function(){
			$rootScope.clearInterval();
			window.location.href=tempContextPath+"/login";
		};
		
		$scope.resetPasswordSubmit=function(pass)
		{
			var from='web';
			if(pass){
				if($scope.errorOnNewPassword || $scope.errorOnRetypePassword){
					$scope.disableSubmitButton=true;
					return false;	
				}
				forgotPasswordRequestService.resetPassword($rootScope.userLogin,pass.newPassword,pass.oldPassword,from).then(
					function success(response)
					 {	
						if(response.error=='false'){
							$rootScope.forcePasswordReset=0;
							 $scope.$emit('event:storeForcePasswordReset');
							$scope.invalidOldPassword={
									value:false
							};
							$scope.confirmation={};
				        	  $scope.confirmation.title = "Reset Password Succsess";
				        	  $scope.confirmation.notification = "Password has been changed successfully.";
				        	  $scope.logout();
							$("#forgotPasswordRequestSuccessModal-module").modal('show');
							
						}else{
							$scope.invalidOldPassword={
									value:true
							};
						}
					
					 },
					 function error(error) {
						 $rootScope.errors = [];
		                if (error != null) {
		                	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
		                  } else {
		                    $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
		                  } 
					 });
				
			};
			
		};
		$scope.checkForNewPasswordMatch=function(newPassword,newPasswordCopy){
			$scope.newPasswordMatchErrorMsg={
					msg:'',
					value:false
			};
			$scope.disableSubmitButton=false;
			$scope.errorOnNewPassword=false;
			if(!newPassword && !newPasswordCopy){
				$scope.newPasswordMatchErrorMsg={
						msg:'',
						value:false
				};
				
			return false;
			}
			if(newPassword!=newPasswordCopy){
				$scope.newPasswordMatchErrorMsg={
						msg:'new password does not match',
						value:true
				};
				$scope.errorOnNewPassword=true;
			}
			
		};
		
		$scope.checkForOldPasswordMatch=function(newPassword,oldPassword)
		{
		$scope.newPasswordAndOldPswrdMatchErrorMsg={
			msg:'',
			value:false
		};
		$scope.disableSubmitButton=false;
		$scope.errorOnRetypePassword=false;
			if(!newPassword && !oldPassword){
					$scope.newPasswordAndOldPswrdMatchErrorMsg={
				msg:'',
				value:false
					};
						return false;
				}
			if(newPassword==oldPassword){
				$scope.newPasswordAndOldPswrdMatchErrorMsg={
				msg:'new password does not match',
				value:true
				};
				$scope.errorOnRetypePassword=true;
			}
		

	};
	
	$scope.logout=function()
	{
		forgotPasswordRequestService.logoutRequest($rootScope.userLogin,$rootScope.userTokenId).then(
		function success(response)
		 {	 
			if(response=='success')
			$rootScope.clearInterval();
			$scope.$emit('event:removeDetails');
			//window.location.href=tempContextPath+"/login";
		 }, 
	     function error(error) {$rootScope.errors = [];
         if (error != null) {
         	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
           } else {
             $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
           } 
		 });	
		
		//$location.path("/login");
	};

		
});
