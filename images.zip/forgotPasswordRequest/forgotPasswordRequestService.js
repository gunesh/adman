DRMApp.service('forgotPasswordRequestService', function ($http,$q,configParameter) {
	
	 this.checkPasswordRequestValidity = function(passwordRequestId) {
			var d = $q.defer();
			$http.get('/'+configParameter.contextPath+'/drmForgotPasswordRequestService/checkPasswordRequestValidity/'+passwordRequestId).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
								d.reject(error);
					});

			return d.promise;
		};
		
		  this.resetPassword = function(userName,newPassword,oldPassword,from) {
			   
		       var d = $q.defer();
		   
		       $http({
		    	   method: 'POST',
		    	   url: '/'+configParameter.contextPath+'/changePassword/'+newPassword+'/'+oldPassword,
		    	   headers: {
		    		   'userLogin': userName,	    		
		    		   'timestamp':new Date(),
		       			'from':from
		          }
		      
		       })
		       
		       .success(function (response) {
		           	
		               d.resolve(response);
		           })
		           .error(function (error) {
		           	
			             d.reject(error);
		           });

		       return d.promise;
		   };
		   
		   this.logoutRequest = function(userName,userTokenId) {
		    	  
		        var d = $q.defer();
		    
		        $http({
		     	   method: 'POST',
		     	   url: '/'+configParameter.contextPath+'/logOut',
		     	   headers: {
		     		   'userLogin': userName,
		     		   'from':'web',
		     		  'userTokenId':userTokenId
		           }
		     	   
		     	 })
		    
		        .success(function (response) {
		            	
		                d.resolve(response);
		            })
		            .error(function (error) {
		            	
		 	             d.reject(error);
		            });

		        
		        return d.promise;
		    };

		   
});

