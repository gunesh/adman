DRMApp.config(['$routeProvider', function($routeProvider) {
   
	$routeProvider
		.when('/Id/:passwordRequestId?', {
			controller: 'forgotPasswordRequestController',
			templateUrl: 'resources/forgotPasswordRequest/views/forgotPasswordRequest.html',
			access: 'public'
		})
		.when('/resetPassword', {
			controller: 'forgotPasswordRequestController',
			templateUrl: 'resources/forgotPasswordRequest/views/froceResetPassword.html'
			
		})
}]);

